system = {
    'screen':
        {
            'width_px': 1280,
            'height_px': 1024
        },
    'sysinfo':
        {
            'class':
                {
                    'status':
                        {
                            'revupdatestat': False
                        },
                    'revsysname': 'fusionOS',
                    'revsyscreate': 'katerkek',
                    'revsysver': 'Концепт 1', #'Beta 1',
                    'revsysinstpath': 'C:\\Users\\милкек\\Desktop\\fOS (Alpha 1)',
                    'revsyslang': 'rus',
                    'revsyscur': 'arrow'
                },
            'smbios':
                {
                    'cpu':
                        {
                            'revcpu': -1,
                            'revcputype': '86',
                            'revcpuname': 'Generic Processor', #'КР1810ВМ86М',
                            'revcpufreq': 'unknown' #'5'
                        },
                    'gpu':
                        {
                            'revgpu': -2,
                            'revgputype': 'GPU',
                            'revgpuname': 'Generic Graphics adapter', #'Realtek RTG3105',
                            'revgpumem': 'unknown' #8
                        },
                    'mem':
                        {
                            'revmem': -3,
                            'revmemtype': '',
                            'revmemname': 'Generic Memory', #'К565Р',
                            'revmemval': 'unknown', #24,
                            'revmemfreq': ''#0
                        },
                    'mbd':
                        {
                            'revmbd': 0,
                            'revmbdtype': 'MBD',
                            'revmbdname': 'Generic Motherboard', #'ПОИСК-2',
                            'revmbdsock': '',
                            'revmbdproc': ''
                        },
                    'lan':
                        {
                            'revlan': -4,
                            'revlantype': 'NET',
                            'revlanname': 'Generic Ethernet adapter', #'3COM EtherLink III',
                            'revlanmode': '',
                            'revlanport': 'COM3'
                        },
                    'aud':
                        {
                            'revaud': -5,
                            'revaudtype': 'AUD',
                            'revaudname': '', #'Creative',
                            'revaudmode': 'Generic Sound adapter', #'Sоund Вlаstеr Midi',
                            'revaudport': 'COM2'
                        },
                    'hdd':
                        {
                            'partitions':
                                {
                                'part-0':
                                    {
                                        'revhdd': -7,
                                        'revhddtype': 'HDD',
                                        'revhddname': 'DOS',
                                        'revhddval': 8,
                                        'revhddport': 'IDE'
                                    },
                                'part-1':
                                    {
                                        'revhdd': -7,
                                        'revhddtype': 'HDD',
                                        'revhddname': 'твой ответ',
                                        'revhddval': 182,
                                        'revhddport': 'IDE'
                                    }
                                },
                            'revhdd': -6,
                            'revhddtype': 'HDD',
                            'revhddname': 'Maxtor XT-2190',
                            'revhddval': 190,
                            'revhddport': 'MFM'
                        },

                }
        },
    'locales':
        {
            'rus':
                {
                    'sysinfo':
                        {
                            'tab':
                                {
                                    'system': 'Система',
                                    'network': 'Сеть',
                                    'storage': 'Хранилище',
                                    'update': 'Обновление'
                                },
                            'about': 'Об этом ПК',
                            'gpu': 'Графика',
                            'aud': 'Звук',
                            'cpu': 'Процессор',
                            'mbd': 'Платформа',
                            'lan': 'Сетевой адаптер',
                            'hdd': 'Жесткий диск',
                            'mbt': 'МБ',
                            'gbt': 'ГБ',
                            'mhz': 'МГц',
                            'ghz': 'МГц',
                            'mem': 'ОЗУ',
                            'unknown': 'Неизвестный',
                            'part': 'Раздел',
                            'noupdf': 'Обновления не найдены',
                            'usinglast': 'Вы используете последнюю версию\n',
                            'connect': 'Подключение',
                            'at': 'на',
                            'updfound': 'обновлений найдено'
                        },
                    'browser':
                        {
                            'back': 'Назад',
                            'forward': 'Вперед',
                            'reload': 'Обновить',
                            'new-t': 'Новая вкладка',
                            'close': 'Закрыть',
                            'find': 'Найти',
                            'settings': 'Настройки',
                            'en-img': 'Включить картинки',
                            'en-stl': 'Включить стили',
                            'en-frm': 'Включить формы',
                            'en-obj': 'Включить объекты',
                            'en-cch': 'Включить кэш',
                            'en-cpr': 'Включить предотвр. сбоев',
                            'en-thr': 'Включить многопоточность',
                            'en-drk': 'Включить темную тему',
                            'en-imi': 'Включить инверсию картинок',
                            'ign-invimg': 'Игнорировать недоп. картинки',
                            'vw-pgs': 'Показать код страницы',
                            'prev': 'Предыдущий',
                            'next': 'Следующий',
                            'ign-cas': 'Игнорировать регистр',
                            'hgh-all': 'Выделить всё',
                            'done': 'Готово',
                            'op-lnk': 'Открыть ссылку',
                            'ol-ntb': 'Открыть ссылку в новой вкладке',
                            'sl-all': 'Выбрать всё',
                            'copy': 'Копировать',
                            'fin-pg': 'Найти на странице',
                            'sel-mtcs': 'Выбрано {} из {} совпадений',
                            'no-mtcs': 'Нет совпадений',
                            'stop': 'Стоп',
                            'name': 'fusion Browser'
                        },
                    'word':
                        {
                            'clear_color': 'Убрать цвет',
                            'clear_font': 'Убрать шрифт',
                            'name': 'fusion TextEdit'
                        },
                    'mediaplayer':
                        {
                        'play': 'Продолжить',
                        'pause': 'Пауза',
                        'name': 'fusion Mediaviewer'
                        },
                    'calc':
                        {
                            'calc': 'Калькулятор'
                        },
                    'irc-chat':
                        {
                            'irc': 'fusion Chat',
                            'join-when-c-start': "Присоединяться при запуске {}",
                            'part-channel': 'Покинуть этот канал',
                            'away': 'Отошел',
                            'show-nots-for-all': 'Показывать уведомления для всех сообщений',
                            'show-user-info': "Показать информацию о пользователе (/whois {})",
                            'send-priv-msg': "Отправить личное сообщение {}",
                            'con-new-serv': 'Подключиться к новому серверу',
                            'leave-serv': 'Покинуть сервер',
                            'serv-settings': 'Настроить сервер',
                            'ask-leave-serv':
                                {
                                    'message': "Вы действительно хотите покинуть {}?",
                                    'detail': "Вы можете переподключиться к нему позже"
                                }
                        },
                    'console':
                        {
                            'name': 'fusion Консоль'
                        },
                    'settings':
                        {
                            'desktop_frame':
                                {
                                    'wallpaper':
                                        {
                                            'clouds': 'Облака',
                                            'system': 'fusion',
                                            'polar': 'Северное сияние',
                                            'lily': 'Кувшинка',
                                            'sea': 'Под водой',
                                            'rain': 'Дождь',
                                            'sky': 'Небо 1',
                                            'sky2': 'Небо 2',
                                            'sky3': 'Небо 3',
                                            'name': 'Обои рабочего стола'
                                        },
                                    'theme':
                                        {
                                            'name': 'Оформление'
                                        }
                                },
                            'name': 'Параметры fusionOS',
                            'dsktp': 'Рабочий стол\nи оформление',
                            'theme': ''
                        },
                    'draw':
                        {
                            'name': 'fusion Draw'
                        },
                    'vk':
                        {
                            'name': 'ВКонтакте'
                        },
                    'system':
                        {
                            'en': 'ENG',
                            'ru': 'РУС',
                            'desktop': 'рабочий стол',
                            'yes': 'Да',
                            'no': 'Нет',
                            'dialog': 'Диалог',
                            'sleep': 'Сон',
                            'sh-dn': 'Выключить'
                        }
                },
            'eng':
                {
                    'sysinfo':
                        {
                            'tab':
                                {
                                    'system': 'System',
                                    'network': 'Network',
                                    'storage': 'Storage',
                                    'update': 'Update'
                                },
                            'about': 'About this PC',
                            'gpu': 'Graphics',
                            'aud': 'Audio',
                            'cpu': 'Processor',
                            'mbd': 'Platform',
                            'lan': 'Network adapter',
                            'hdd': 'HDD',
                            'mbt': 'MB',
                            'gbt': 'GB',
                            'mhz': 'MHz',
                            'ghz': 'MHz',
                            'unknown': 'Unknown',
                            'part': 'Partition',
                            'noupdf': 'No updates found',
                            'usinglast': 'You are using the latest version',
                            'connect': 'Connection',
                            'yes': 'Yes',
                            'no': 'No',
                            'at': 'at',
                            'updfound': 'updates found',
                            'mem': 'RAM'
                        },
                    'browser':
                        {
                            'back': 'Back',
                            'forward': 'Forward',
                            'reload': 'Reload',
                            'new-t': 'New tab',
                            'close': 'Close',
                            'find': 'Find',
                            'settings': 'Settings',
                            'en-img': 'Enable images',
                            'en-stl': 'Enable stylesheets',
                            'en-frm': 'Enable forms',
                            'en-obj': 'Enable objects',
                            'en-cch': 'Enable caches',
                            'en-cpr': 'Enable crash prevention',
                            'en-thr': 'Enable threading',
                            'en-drk': 'Enable dark theme',
                            'en-imi': 'Enable image inverter',
                            'ign-invimg': 'Ignore invalid images',
                            'vw-pgs': 'View page source',
                            'prev': 'Previous',
                            'next': 'Next',
                            'ign-cas': 'Ignore cases',
                            'hgh-all': 'Highlight all',
                            'done': 'Done',
                            'op-lnk': 'Open link',
                            'ol-ntb': 'Open link in new tab',
                            'sl-all': 'Select all',
                            'copy': 'Copy',
                            'fin-pg': 'Find in page',
                            'sel-mtcs': 'Selected {} of {} matches',
                            'no-mtcs': 'No matches',
                            'stop': 'Stop',
                            'name': 'fusion Browser'
                        },
                    'word':
                        {
                            'clear_color': 'Clear color',
                            'clear_font': 'Clear font',
                            'name': 'Word 2002'
                        },
                    'draw':
                        {
                            'name': 'fusion Draw'
                        },
                    'settings':
                        {
                            'desktop_frame':
                                {
                                    'wallpaper':
                                        {
                                            'clouds': 'Clouds',
                                            'system': 'fusion',
                                            'polar': 'Polar light',
                                            'lily': 'Water lily',
                                            'sea': 'Under water',
                                            'rain': 'Rain',
                                            'sky': 'Sky 1',
                                            'sky2': 'Sky 2',
                                            'sky3': 'Sky 3',
                                            'name': 'Desktop wallpaper'
                                        },
                                    'theme':
                                        {
                                            'name': 'Theme'
                                        }
                                },
                            'name': 'fusionOS Settings',
                            'dsktp': 'Desktop\nand theme',
                            'theme': ''
                        },
                    'mediaplayer':
                        {
                            'play': 'Play',
                            'pause': 'Pause',
                            'name': 'fusion Mediaviewer'
                        },
                    'calc':
                        {
                            'calc': 'Calculator'
                        },
                    'irc-chat':
                        {
                            'irc': 'fusion Chat',
                            'join-when-c-start': "Join when {} starts",
                            'part-channel': 'Part channel',
                            'away': 'Away',
                            'show-nots-for-all': 'Show notifications for all',
                            'show-user-info': "Show user info (/whois {})",
                            'send-priv-msg': "Send private message {}",
                            'con-new-serv': 'Connect to new server',
                            'leave-serv': 'Leave server',
                            'serv-settings': 'Server settings',
                            'ask-leave-serv':
                                {
                                    'message': "Are you sure you want to quit {}?",
                                    'detail': "You can reconnect to it later."
                                }
                        },
                    'console':
                        {
                            'name': 'fusion Console'
                        },
                    'vk':
                        {
                            'name': 'VKontakte'
                        },

                    'system':
                        {
                            'en': 'ENG',
                            'ru': 'RUS',
                            'desktop': 'desktop',
                            'yes': 'Yes',
                            'no': 'No',
                            'dialog': 'Dialog',
                            'sleep': 'Sleep',
                            'sh-dn': 'Shut down'
                        }
                }
        },
    'theme':
        {
            'programs':
                {
                    'dock':
                        {
                            'calc': 'etc/theme/programs/dock/calc.png',
                            'freyo': 'etc/theme/programs/dock/freyo.png',
                            'word': 'etc/theme/programs/dock/word.png',
                            'paint': 'etc/theme/programs/dock/paint.png',
                            'hdd': 'etc/theme/programs/dock/paint.png',
                            'mp': 'etc/theme/programs/dock/mp.png',
                            'recycle-0': 'etc/theme/programs/dock/recycle-0.png',
                            'recycle-1': 'etc/theme/programs/dock/recycle-1.png',
                            'settings': 'etc/theme/programs/dock/settings.png',
                            'terminal': 'etc/theme/programs/dock/terminal.png',
                            'vkapp': 'etc/theme/programs/dock/vkapp.png',
                            'chat': 'etc/theme/programs/dock/chat.png'
                        },
                    'sysinfo':
                        {
                            'f_logo': 'etc/theme/programs/sysinfo/f_logo.png',
                            'hdd': 'etc/theme/programs/sysinfo/hdd.png'
                        },
                    'menu':
                        {
                            'f_logo': 'etc/theme/programs/menu/f_logo.png'
                        },
                    'system':
                        {
                            'checkbox-0': 'etc/theme/programs/system/checkbox-0.png',
                            'checkbox-1': 'etc/theme/programs/system/checkbox-1.png',
                            'clock': 'etc/theme/programs/system/clock.png'
                        },
                    'settings':
                        {
                            'desktop': 'etc/theme/programs/settings/desktop.png'
                        }
                },
            'wallpaper':
                {
                    'system': 'etc/theme/wallpaper/fos.png',
                    'polar': 'etc/theme/wallpaper/polar_light.png',
                    'clouds': 'etc/theme/wallpaper/clouds.png',
                    'sky': 'etc/theme/wallpaper/sky.png',
                    'sky2': 'etc/theme/wallpaper/sky2.png',
                    'sky3': 'etc/theme/wallpaper/sky3.png',
                    'sea': 'etc/theme/wallpaper/sea.png',
                    'rain': 'etc/theme/wallpaper/rain.png',
                    'lily': 'etc/theme/wallpaper/lily.png'
                },
            'theme':
                {
                    'system': ('#447a84', '#d7d8d8'),
                    'polar': ('#50668f', '#dd9db8'),
                    'clouds': ('#4764a0', '#9ac0e5'),
                    'sea': ('#021132', '#b2ecf8'),
                    'rain': ('#669dd5', '#042a69'),
                    'lily': ('#535f31', '#edbf4f'),
                    'sky': ('#414d75', '#dbdbe7'),
                    'sky2': ('#063eab', '#6da7fb'),
                    'sky3': ('#201f97', '#993f3e')
                }
        },
    'programs':
        {
            'browser':
                {
                    'new-tab': 'https://ru.search.yahoo.com/'
                }
        }
}

fullscreen = True