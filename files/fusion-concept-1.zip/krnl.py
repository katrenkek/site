import math
import tkinter as tk
from datetime import datetime
import ctypes
from pathlib import Path
from random import choice
from typing import Callable
import etc.irc.gui as gui
import keyboard
from etc.system import registry as reg
import tkinterweb
from tkVideoPlayer import TkinterVideo
import argparse
import sys
import time
import platformdirs
import etc.irc.commands as commands, etc.irc.config as config, etc.irc.logs as logs
from tkinter import ttk
from tkinterweb import HtmlFrame, Notebook, __version__
from tkinterweb.utilities import BUILTINPAGES
import os
from PIL import Image, ImageTk
from etc.chrm.tkinter_ import MainFrame as __vk_app_main_frame__

nv = tk.Tk()
nv.title(reg.system['sysinfo']['class']['revsysname'])
nv.geometry(f"{reg.system['screen']['width_px']}x{reg.system['screen']['height_px']}")
nv.attributes('-fullscreen', reg.fullscreen)
nv.configure(cursor=reg.system['sysinfo']['class']['revsyscur'])

current_color_scheme = reg.system['theme']['theme']['system']
current_wallpaper_text = ''
current_theme_text = ''

class GradientFrame(tk.Canvas):
    '''A gradient frame which uses a canvas to draw the background'''
    def __init__(self, parent, **kwargs):
        tk.Canvas.__init__(self, parent, **kwargs)
        self.bind("<Configure>", self._draw_gradient)

    def _draw_gradient(self, event=None, **kw):
        '''Draw the gradient'''
        self.delete("gradient")
        width = self.winfo_width()
        height = self.winfo_height()
        limit = width
        if 'color' in kw:
            self._color1, self._color2 = kw['color']
        else:
            self._color1, self._color2 = current_color_scheme
        (r1,g1,b1) = self.winfo_rgb(self._color1)
        (r2,g2,b2) = self.winfo_rgb(self._color2)
        r_ratio = float(r2-r1) / limit
        g_ratio = float(g2-g1) / limit
        b_ratio = float(b2-b1) / limit

        for i in range(limit):
            nr = int(r1 + (r_ratio * i))
            ng = int(g1 + (g_ratio * i))
            nb = int(b1 + (b_ratio * i))
            color = "#%4.4x%4.4x%4.4x" % (nr,ng,nb)
            self.create_line(i,0,i,height, tags=("gradient",), fill=color)
            self.lower("gradient")

class BarGradientFrame(tk.Canvas):
    '''A gradient frame which uses a canvas to draw the background'''
    def __init__(self, parent, color=current_color_scheme, **kwargs):
        tk.Canvas.__init__(self, parent, **kwargs)
        self._color1, self._color2 = color
        self.bind("<Configure>", self._draw_gradient)

    def _draw_gradient(self, event=None):
        '''Draw the gradient'''
        self.delete("gradient")
        width = self.winfo_width()
        height = self.winfo_height()
        limit = width
        (r1,g1,b1) = self.winfo_rgb(self._color1)
        (r2,g2,b2) = self.winfo_rgb(self._color2)
        r_ratio = float(r2-r1) / limit
        g_ratio = float(g2-g1) / limit
        b_ratio = float(b2-b1) / limit

        for i in range(limit):
            nr = int(r1 + (r_ratio * i))
            ng = int(g1 + (g_ratio * i))
            nb = int(b1 + (b_ratio * i))
            color = "#%4.4x%4.4x%4.4x" % (nr,ng,nb)
            self.create_line(i,0,i,height, tags=("gradient",), fill=color)
            self.lower("gradient")

def CreateDialog(**kw):
    dialog = CreateWindow(id='null')
    dialog.bar.window_label['text'] = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['system']['dialog']
    dialog.bar.bind('<ButtonPress-1>', lambda event: None)
    dialog.bar.bind('<B1-Motion>', lambda event: None)
    dialog.place(x=reg.system['screen']['width_px']/2-dialog.wW/2, y=reg.system['screen']['height_px']/2-dialog.hH/2)

def CreateWindow(**kw):
    global window_current_x, window_current_y, window_minimized, desktop

    window_minimized = False
    window_current_x = 0
    window_current_y = 0

    window_width = 300
    window_height = 400

    if desktop.window_y >= 535:
        desktop.window_x += 50
        desktop.window_y = 35

    def _press(event):
        window_bar.x = event.x
        window_bar.y = event.y
        focus()

    def _release(event):
        x = event.x - window_bar.x + window_bar.winfo_x()
        y = event.y - window_bar.y + window_bar.winfo_y()
        window_bar.place(x=x, y=y)
        window.place(x=x, y=y+20)
        window.x0.place_forget()
        window.x1.place_forget()
        window.y0.place_forget()
        window.y1.place_forget()
        window_bar.lift()
        window.lift()
        desktop.dock.lift()

    def _motion(event):
        x0_x = event.x - window_bar.x + window_bar.winfo_x()
        x0_y = event.y - window_bar.y + window_bar.winfo_y()

        x1_x = event.x - window_bar.x + window_bar.winfo_x() + window.winfo_width() - 0
        x1_y = event.y - window_bar.y + window_bar.winfo_y()

        y0_x = event.x - window_bar.x + window_bar.winfo_x()
        y0_y = event.y - window_bar.y + window_bar.winfo_y() + window.winfo_height() - 0 + 20

        y1_x = event.x - window_bar.x + window_bar.winfo_x()
        y1_y = event.y - window_bar.y + window_bar.winfo_y()

        window.x0.place_forget()
        window.x1.place_forget()
        window.y0.place_forget()
        window.y1.place_forget()

        window.x0.place(x=x0_x, y=x0_y)
        window.x1.place(x=x1_x, y=x1_y)
        window.y0.place(x=y0_x, y=y0_y)
        window.y1.place(x=y1_x, y=y1_y)

        window.x0.lift()
        window.x1.lift()
        window.y0.lift()
        window.y1.lift()

    def focus(event=None):
        window_bar.lift()
        window.lift()
        desktop.dock.lift()
        for a in nv.windows:
            if not a == window:
                a.bar.theme._draw_gradient(color=('#4d4d4d', '#a3a3a3'))
            else:
                a.bar.theme._draw_gradient()

    def __dummy(event):
        pass

    def close():
        menustr.windows.rem(window)
        nv.windows.remove(window)
        window_bar.destroy()
        window.destroy()
        desktop.window_x -= 50
        desktop.window_y -= 50
        nv.windows[len(nv.windows)-1].bar.theme._draw_gradient()
        nv.windows[len(nv.windows) - 1].bar.lift()
        nv.windows[len(nv.windows) - 1].lift()
        desktop.dock.lift()

    def minimize():
        global window_current_x, window_current_y, window_minimized
        if window_minimized:
            window_bar.place(x=window_current_x, y=window_current_y)
            window.place(x=window_current_x, y=window_current_y+20)
            window_minimized = False
            desktop.minimized_windows -= 1
            window_bar.lift()
            window.lift()
        else:
            window_current_x = window_bar.winfo_x()
            window_current_y = window_bar.winfo_y()
            window_bar.place_forget()
            window.place_forget()
            window_minimized = True
            desktop.minimized_windows += 1


    def maximize():
        window_bar['width'] = reg.system['screen']['width_px']
        window['width'] = reg.system['screen']['width_px']
        window['height'] = reg.system['screen']['height_px']-25-85
        window_bar.theme['width'] = reg.system['screen']['width_px'] - 4

        window_bar.place(x=0, y=0)
        window.place(x=0, y=20)

        window_bar.theme.bind("<ButtonPress-1>", focus)
        window_bar.theme.bind("<ButtonRelease-1>", __dummy)
        window_bar.theme.bind("<B1-Motion>", __dummy)

        window_bar.window_maximize['command'] = make_stand

    def make_stand():
        window_bar['width'] = window_width
        window['width'] = window_width
        window['height'] = window_height
        window_bar.theme['width'] = window_width - 4

        window_bar.place(x=desktop.window_x, y=desktop.window_y)
        window.place(x=desktop.window_x, y=desktop.window_y+20)

        window_bar.theme.bind("<ButtonPress-1>", _press)
        window_bar.theme.bind("<ButtonRelease-1>", _release)
        window_bar.theme.bind("<B1-Motion>", _motion)

        window_bar.window_maximize['command'] = maximize

    window_bar = tk.Frame(desktop, relief='raised', borderwidth=2, bg='white', width=window_width, height=30)
    window_bar.place(x=desktop.window_x, y=desktop.window_y)

    window_bar.theme = GradientFrame(window_bar, width=window_width-4, height=20-4, relief='raised', borderwidth=2)
    window_bar.theme.place(x=-4, y=-4)

    window = tk.Frame(desktop, relief='raised', borderwidth=2, bg='white', width=window_width, height=window_height)
    window.place(x=desktop.window_x, y=desktop.window_y+20)

    window.x0 = tk.Frame(desktop, width=window_width, height=2, bg='#0b0b0b', relief='raised', borderwidth=2)
    window.x1 = tk.Frame(desktop, width=2, height=window_height, bg='#0b0b0b', relief='raised', borderwidth=2)
    window.y0 = tk.Frame(desktop, width=window_width+2, height=2, bg='#0b0b0b', relief='raised', borderwidth=2)
    window.y1 = tk.Frame(desktop, width=2, height=window_height, bg='#0b0b0b', relief='raised', borderwidth=2)

    window_bar.window_label = window_bar.theme.create_text(window_width/2, 20/2+2, text='Window', fill='white')
    window_bar.window_close = tk.Button(window_bar, text='', bg='#c14238', activebackground='#700000', command=close)
    window_bar.window_close.place(x=3, y=3, width=12, height=11)
    window_bar.window_minimize = tk.Button(window_bar, text='', bg='#e6a141', activebackground='#786400', command=minimize)
    window_bar.window_minimize.place(x=17, y=3, width=12, height=11)
    window_bar.window_maximize = tk.Button(window_bar, text='', bg='#6eba4b', activebackground='#146300', command=maximize)
    window_bar.window_maximize.place(x=31, y=3, width=12, height=11)

    window.bar = window_bar
    window.wW, window.hH = window_width, window_height

    window_bar.theme.bind("<ButtonPress-1>", _press)
    window_bar.theme.bind("<ButtonRelease-1>", _release)
    window_bar.theme.bind("<B1-Motion>", _motion)

    window.pack_propagate(0)

    if 'id' in kw:
        if kw['id'] == 'browser':

            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['name'])
            window_width = 800
            window_height = 600
            window_bar['width'] = window_width
            window_bar.theme['width'] = window_width-4
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            window['width'] = window_width
            window['height'] = window_height

            if os.name == "nt":
                from ctypes import windll
                windll.shcore.SetProcessDpiAwareness(1)

            NEW_TAB = reg.system['programs']['browser']['new-tab']

            class Page(tk.Frame):
                def __init__(self, master, *args, **kwargs):
                    tk.Frame.__init__(self, master, *args, **kwargs)

                    self.master = master
                    self.back_history = []
                    self.forward_history = []

                    self.frame = frame = HtmlFrame(self, messages_enabled=False)
                    topbar = tk.Frame(self)
                    self.bottombar = bottombar = tk.Frame(self)
                    self.findbar = findbar = tk.Frame(self)
                    self.sidebar = sidebar = HtmlFrame(frame, messages_enabled=False, width=250)
                    self.sidebar.background = 'white'
                    sidebar.grid_propagate(False)
                    sidebar.set_fontscale(0.8)
                    sidebar.html.selection_enabled = False
                    self.linklabel = linklabel = tk.Label(bottombar, text="", cursor="hand2")

                    self.backbutton = backbutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['back'], command=self.back, state="disabled")
                    self.forwardbutton = forwardbutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['forward'], command=self.forward,
                                                                   state="disabled")
                    self.reloadbutton = reloadbutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['reload'], command=self.reload, cursor="hand2")
                    self.urlbar = urlbar = tk.Entry(topbar)
                    newbutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['new-t'], command=self.open_new_tab, cursor="hand2")
                    closebutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['close'], command=self.close_current_tab, cursor="hand2")
                    self.findbutton = findbutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['find'], command=self.open_findbar, cursor="hand2")
                    self.settingsbutton = settingsbutton = tk.Button(topbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['settings'], command=self.open_sidebar,
                                                                     cursor="hand2")

                    self.images_var = images_var = tk.IntVar(value=1)
                    images_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-img'], variable=images_var,
                                                    command=self.toggle_images)
                    self.styles_var = styles_var = tk.IntVar(value=1)
                    styles_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-stl'], variable=styles_var,
                                                    command=self.toggle_styles)
                    self.forms_var = forms_var = tk.IntVar(value=1)
                    forms_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-frm'], variable=forms_var,
                                                   command=self.toggle_forms)
                    self.objects_var = objects_var = tk.IntVar(value=1)
                    objects_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-obj'], variable=objects_var,
                                                     command=self.toggle_objects)
                    self.caches_var = caches_var = tk.IntVar(value=1)
                    caches_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-cch'], variable=caches_var,
                                                    command=self.toggle_caches)
                    self.emojis_var = emojis_var = tk.IntVar(value=1)
                    emojis_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-cpr'], variable=emojis_var,
                                                    command=self.toggle_emojis)
                    self.threads_var = threads_var = tk.IntVar(value=1)
                    threads_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-thr'], variable=threads_var,
                                                     command=self.toggle_threads)
                    self.invert_page_var = invert_page_var = tk.IntVar(value=0)
                    invert_page_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-drk'], variable=invert_page_var,
                                                         command=self.toggle_theme)
                    self.invert_images_var = invert_images_var = tk.IntVar(value=0)
                    invert_images_enabled = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['en-imi'], variable=invert_images_var,
                                                           command=self.toggle_theme)

                    self.ignoreimages_var = ignoreimages_var = tk.IntVar(value=1)
                    ignore_invalid_images = tk.Checkbutton(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['ign-invimg'], variable=ignoreimages_var,
                                                           command=self.toggle_ignore_invalid_images)
                    self.zoom_var = zoom_var = tk.StringVar(value=self.frame.get_zoom())
                    self.zoom_box = zoom_box = tk.Scale(sidebar, from_=0.1, to=5, orient="horizontal", variable=zoom_var,
                                                        command=self.set_zoom)
                    self.parsemode_var = parsemode_var = tk.StringVar(value=frame.get_parsemode())
                    self.parsemode_box = parsemode_box = tk.Entry(sidebar, textvariable=parsemode_var)
                    self.broken_page_msg_box = broken_page_msg_box = tk.Text(sidebar, wrap=tk.WORD, width=30, undo=True)
                    self.view_source_button = view_source_button = tk.Button(sidebar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['vw-pgs'],
                                                                             command=self.view_source)
                    about_button = tk.Button(sidebar, text="About TkinterWeb",
                                             command=lambda url="about:tkinterweb": self.open_new_tab(url))
                    self.message_box = tk.Text(self, height=8)

                    self.find_select_num = 1
                    self.find_match_num = 0

                    self.findbox_var = findbox_var = tk.StringVar()
                    self.find_box = find_box = tk.Entry(findbar, textvariable=findbox_var)
                    self.find_previous = find_previous = tk.Button(findbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['prev'], command=self.previous_and_find,
                                                                   state="disabled")
                    self.find_next = find_next = tk.Button(findbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['next'], command=self.next_and_find,
                                                           state="disabled")
                    self.ignore_case_var = ignore_case_var = tk.IntVar(value=1)
                    ignore_case = tk.Checkbutton(findbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['ign-cas'], variable=ignore_case_var,
                                                 command=self.search_in_page, cursor="hand2")
                    self.highlight_all_var = highlight_all_var = tk.IntVar(value=1)
                    highlight_all = tk.Checkbutton(findbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['hgh-all'], variable=highlight_all_var,
                                                   command=lambda change=False: self.search_in_page(change=change),
                                                   cursor="hand2")
                    self.find_bar_caption = find_bar_caption = tk.Label(findbar, text="")
                    find_close = tk.Button(findbar, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['close'], command=self.open_findbar, cursor="hand2")

                    frame.on_title_change(self.change_title)
                    frame.on_link_click(self.link_click)
                    frame.on_form_submit(self.form_submit)
                    frame.on_url_change(self.url_change)
                    frame.on_done_loading(self.done_loading)
                    frame.set_message_func(self.add_message)
                    frame.on_downloading_resource(self.on_downloading)

                    linklabel.bind("<Button-1>", self.hide_messsage_box)
                    urlbar.bind("<Return>", self.load_site)
                    # frame.bind("<Motion>", self.on_motion)
                    frame.bind("<Leave>", lambda event: linklabel.config(text="Done"))
                    broken_page_msg_box.bind("<<Modified>>", self.broken_page_msg_update)
                    broken_page_msg_box.bind('<KeyRelease>', self.broken_page_msg_change)

                    self.columnconfigure(0, weight=1)
                    self.rowconfigure(1, weight=1)
                    topbar.grid(column=0, row=0, sticky="ew")
                    frame.grid(column=0, row=1, sticky="nsew")
                    bottombar.grid(column=0, row=4, sticky="ew")

                    self.sidebar.load_html(f"""<style>body {{background-color: {self.sidebar.background}}} p, span {{margin-top: 5px; margin-bottom: 5px; cursor: default}} object {{width: 100%; cursor: pointer}}</style>
                                               <object allowscrolling data={images_enabled}></object><br>
                                               <object allowscrolling data={styles_enabled}></object><br>
                                               <object allowscrolling data={forms_enabled}></object><br>
                                               <object allowscrolling data={objects_enabled}></object><br>
                                               <object allowscrolling data={caches_enabled}></object><br>
                                               <object allowscrolling data={emojis_enabled}></object>
                                               <object allowscrolling data={threads_enabled}></object><hr></hr>
                                               <object allowscrolling data={invert_page_enabled}></object><br>
                                               <object allowscrolling data={invert_images_enabled}></object><hr></hr>
                                               <object allowscrolling data={ignore_invalid_images}></object><hr></hr>
                                               <div><p style="float:left">Zoom:</p><span style="float:right" id="zoom">{zoom_var.get()}</span><object allowscrolling data={zoom_box}></object></div>
                                               <div><p style="float:left">Font scale:</p><span style="float:right" id="fontscale">{0}</span></div><hr></hr>
                                               <p>Parse mode:</p><object allowscrolling data={parsemode_box}></object><hr></hr>
                                               <p>Broken page message:</p><object allowscrolling data={broken_page_msg_box}></object><hr></hr>
                                               <object allowscrolling data={view_source_button}></object>
                                               <object allowscrolling data={about_button}></object>
                        """)

                    linklabel.pack(expand=True, fill="both")
                    topbar.columnconfigure(4, weight=1)
                    backbutton.grid(row=0, column=1, pady=5, padx=5)
                    forwardbutton.grid(row=0, column=2, pady=5)
                    reloadbutton.grid(row=0, column=3, pady=5, padx=5)
                    urlbar.grid(row=0, column=4, pady=5, padx=3, sticky="NSEW")
                    newbutton.grid(row=0, column=5, pady=5, padx=5)
                    closebutton.grid(row=0, column=6, pady=5, padx=5)
                    findbutton.grid(row=0, column=7, pady=5)
                    settingsbutton.grid(row=0, column=8, pady=5, padx=5)

                    findbar.columnconfigure(6, weight=1)
                    find_box.grid(row=0, column=0, padx=5)
                    find_previous.grid(row=0, column=1)
                    find_next.grid(row=0, column=2)
                    ttk.Separator(findbar, orient="vertical").grid(row=0, column=3, sticky="ns", pady=4, padx=8)
                    ignore_case.grid(row=0, column=4, sticky="ns")
                    highlight_all.grid(row=0, column=5, sticky="ns", padx=5)
                    find_bar_caption.grid(row=0, column=7)
                    find_close.grid(row=0, column=8, sticky="ns", padx=5)
                    ttk.Separator(findbar).grid(row=1, column=0, columnspan=9, sticky="ew", pady=4, padx=8)

                    findbox_var.trace("w", self.search_in_page)
                    parsemode_var.trace("w", self.set_parsemode)

                    broken_page_msg_box.insert("end", 'about:error')

                    frame.bind("<Button-3>", self.on_right_click)
                    for widget in [urlbar, find_box, parsemode_box, zoom_box]:
                        widget.bind("<Control-a>", lambda e: self.after(50, self.select_all_in_entry, e.widget))
                    broken_page_msg_box.bind("<Control-a>", lambda e: self.after(50, self.select_all_in_text, e.widget))

                    for child in findbar.winfo_children():
                        child.bind("<Escape>", lambda x: self.open_findbar())
                    for child in sidebar.winfo_children():
                        child.bind("<Escape>", lambda x: self.close_sidebar())
                    settingsbutton.bind("<Escape>", lambda x: self.close_sidebar())

                def select_all_in_entry(self, widget):
                    widget.select_range(0, 'end')
                    widget.icursor('end')

                def select_all_in_text(self, widget):
                    widget.tag_add(tk.SEL, "1.0", tk.END)
                    widget.mark_set(tk.INSERT, "1.0")
                    widget.see(tk.INSERT)

                def on_right_click(self, event):
                    url = self.frame.get_current_link(resolve=True)
                    selection = self.frame.get_currently_selected_text()
                    menu = tk.Menu(self, tearoff=0)
                    if len(self.back_history) > 1:
                        menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['back'], accelerator="", command=self.back)
                    if len(self.forward_history) == 1:
                        menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['forward'], command=self.forward)
                    menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['reload'], accelerator="Ctrl-R", command=self.reload)
                    menu.add_separator()
                    if url:
                        menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['op-lnk'], command=lambda url=url: self.link_click(url))
                        menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['ol-ntb'], command=lambda url=url: self.open_new_tab(url))
                        menu.add_separator()
                    menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['sl-all'], accelerator="Ctrl-A", command=self.frame.select_all)
                    if selection:
                        menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['copy'], accelerator="Ctrl-C", command=self.frame.html.copy_selection)
                    menu.add_separator()
                    menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['fin-pg'], accelerator="Ctrl-F", command=lambda: self.open_findbar(True))
                    if str(self.view_source_button.cget("state")) == "normal":
                        menu.add_command(label=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['vw-pgs'], accelerator="Ctrl-U", command=self.view_source)
                    menu.tk_popup(event.x_root, event.y_root, 0)

                def urlbar_focus(self):
                    self.urlbar.focus()
                    self.urlbar.select_range(0, 'end')
                    self.urlbar.icursor('end')

                def previous_and_find(self):
                    self.find_select_num -= 1
                    if self.find_select_num == 0:
                        self.find_select_num = self.find_match_num
                    self.search_in_page(change=False)

                def next_and_find(self):
                    self.find_select_num += 1
                    if self.find_select_num == self.find_match_num + 1:
                        self.find_select_num = 1
                    self.search_in_page(change=False)

                def search_in_page(self, x=None, y=None, change=True):
                    if change:
                        self.find_select_num = 1
                    self.find_match_num = self.frame.find_text(self.findbox_var.get(), self.find_select_num,
                                                               self.ignore_case_var.get(), self.highlight_all_var.get())
                    if self.find_match_num > 0:
                        self.find_bar_caption.configure(
                            text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['sel-mtcs'].format(self.find_select_num, self.find_match_num))
                    else:
                        self.find_bar_caption.configure(text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['no-mtcs'])

                    if self.find_match_num > 1:
                        self.find_previous.config(state="normal", cursor="hand2")
                        self.find_next.config(state="normal", cursor="hand2")
                    else:
                        self.find_previous.config(state="disabled", cursor="arrow")
                        self.find_next.config(state="disabled", cursor="arrow")

                def hide_messsage_box(self, event):
                    if self.message_box.winfo_ismapped():
                        self.message_box.grid_forget()
                    else:
                        self.message_box.grid(column=0, row=5, sticky="ew", padx=4, pady=(0, 4,))

                def add_message(self, message):
                    self.message_box.insert("end", message + "\n\n")
                    self.message_box.yview("end")
                    if f"Error loading {self.urlbar.get()}" in message:
                        self.handle_view_source_button("about:error")
                    self.linklabel.config(text=self.cut_text(message, 80))

                def recursive_depth_change(self, *args):
                    self.frame.set_recursive_hover_depth(self.recursive_depth_var.get())

                def thread_count_change(self, *args):
                    self.frame.set_maximum_thread_count(self.thread_count_var.get())

                def broken_page_msg_update(self, event=None):
                    height = self.broken_page_msg_box.count("1.0", "end", "displaylines")[0]
                    self.broken_page_msg_box.configure(height=height)
                    self.broken_page_msg_box.edit_modified(False)

                def broken_page_msg_change(self, event):
                    self.frame.set_broken_webpage_message(event.widget.get("1.0", 'end-1c'))

                def toggle_images(self):
                    self.frame.enable_images(self.images_var.get())
                    self.reload()

                def toggle_styles(self):
                    self.frame.enable_stylesheets(self.styles_var.get())
                    self.reload()

                def toggle_forms(self):
                    self.frame.enable_forms(self.forms_var.get())
                    self.reload()

                def toggle_objects(self):
                    self.frame.enable_objects(self.objects_var.get())
                    self.reload()

                def toggle_caches(self):
                    self.frame.enable_caches(self.caches_var.get())
                    self.reload()

                def toggle_emojis(self):
                    self.frame.enable_crash_prevention(self.emojis_var.get())
                    self.reload()

                def toggle_threads(self):
                    if self.threads_var.get():
                        self.frame.set_maximum_thread_count(self.original_thread_count)
                    else:
                        self.original_thread_count = self.frame.html.max_thread_count
                        self.frame.set_maximum_thread_count(0)
                    self.reload()

                def toggle_theme(self):
                    self.frame.enable_dark_theme(self.invert_page_var.get(), self.invert_images_var.get())
                    self.reload()

                def toggle_ignore_invalid_images(self):
                    self.frame.ignore_invalid_images(self.ignoreimages_var.get())
                    self.reload()

                def open_sidebar(self, keep_open=False):
                    self.sidebar.grid_propagate(False)
                    if self.sidebar.winfo_ismapped() and not keep_open:
                        self.close_sidebar()
                    else:
                        self.sidebar.grid(row=0, column=2, sticky="nsew")
                        self.sidebar.update()
                        self.broken_page_msg_box.update()
                        self.broken_page_msg_update()

                def close_sidebar(self):
                    if self.sidebar.winfo_ismapped():
                        self.sidebar.grid_forget()

                def open_findbar(self, keep_open=False):
                    if self.findbar.winfo_ismapped() and not keep_open:
                        self.findbar.grid_forget()
                        self.frame.find_text("")
                    else:
                        self.findbar.grid(column=0, row=2, sticky="ew", pady=(4, 0,))
                        self.find_box.focus()

                def on_motion(self, event):
                    text = self.frame.get_currently_hovered_node_text()
                    link = self.frame.get_currently_hovered_node_attribute("href")
                    if link:
                        self.linklabel.config(text=self.cut_text("Hyper-link: " + link, 80))
                    elif text:
                        self.linklabel.config(text=self.cut_text("Text: " + text, 80))
                    else:
                        elm = self.frame.get_currently_hovered_node_tag()
                        self.linklabel.config(text=self.cut_text("Element: " + elm, 80))

                def back(self):
                    if len(self.back_history) == 1:
                        return
                    self.forwardbutton.config(state="normal", cursor="hand2")
                    self.forward_history.append(self.back_history[-1])
                    url = self.back_history[-2]
                    self.back_history = self.back_history[:-1]
                    self.frame.load_url(url)
                    if len(self.back_history) <= 1:
                        self.backbutton.config(state="disabled", cursor="arrow")
                    self.url_change(url)

                def on_downloading(self):
                    self.reloadbutton.config(text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['stop'], command=self.frame.stop)

                def forward(self):
                    if len(self.forward_history) == 0:
                        return
                    url = self.forward_history[-1]
                    self.forward_history = self.forward_history[:-1]
                    if self.forward_history == []:
                        self.forwardbutton.config(state="disabled", cursor="arrow")
                    self.backbutton.config(state="normal", cursor="hand2")
                    self.back_history.append(url)
                    self.frame.load_url(url)
                    self.url_change(url)

                def cut_text(self, text, limit):
                    if (len(text) > limit):
                        text = text[:limit] + "..."
                    return text

                def focus_on_url(self):
                    self.urlbar.focus()
                    self.urlbar.select_range(0, 'end')

                def open_new_tab(self, url=NEW_TAB):
                    page = Page(self.master)
                    self.master.add(page, text='')
                    self.master.select(page)
                    page.link_click(url, history=False)

                def close_current_tab(self):
                    self.master.forget(self)

                def set_zoom(self, *args):
                    self.frame.set_zoom(self.zoom_var.get())
                    self.sidebar.document.getElementById("zoom").textContent(round(float(self.zoom_var.get()), 1))

                def set_fontscale(self, *args):
                    self.frame.set_fontscale(self.fontscale_var.get())
                    self.sidebar.document.getElementById("fontscale").textContent(round(float(self.fontscale_var.get()), 1))

                def set_parsemode(self, *args):
                    if self.parsemode_var.get() not in ["html", "xml", "xhtml"]:
                        self.parsemode_box.config(background="#ff6959")
                    else:
                        self.parsemode_box.config(background="white")
                        self.frame.set_parsemode(self.parsemode_var.get())

                def done_loading(self):
                    self.linklabel.config(text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['done'])
                    self.reloadbutton.config(text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['reload'], command=self.reload)

                def handle_view_source_button(self, url):
                    if url in BUILTINPAGES or url.startswith("view-source:"):
                        self.view_source_button.config(state="disabled", cursor="arrow")
                    else:
                        self.view_source_button.config(state="normal", cursor="hand2")

                def url_change(self, url):
                    self.master.tab(self, text=self.cut_text(url, 40))
                    self.urlbar.delete(0, "end")
                    self.urlbar.insert(0, url)
                    self.handle_view_source_button(url)

                def addtohist(self, url):
                    self.back_history.append(url)
                    self.forward_history = []
                    self.forwardbutton.config(state="disabled", cursor="arrow")
                    self.backbutton.config(state="normal", cursor="hand2")

                def form_submit(self, url, data, method="GET"):
                    if method == "GET":
                        self.addtohist(url + data)
                    else:
                        self.addtohist(url)
                    self.frame.load_form_data(url, data, method)

                def load_site(self, event):
                    url = self.urlbar.get()
                    if not any((url.startswith("file:"), url.startswith("http:"), url.startswith("about:"),
                                url.startswith("view-source:"), url.startswith("https:"), url.startswith("data:"))):
                        url = "http://{}".format(url)
                    self.addtohist(url)
                    self.frame.load_url(url)
                    self.handle_view_source_button(url)

                def link_click(self, url, history=True):
                    self.addtohist(url)
                    if not history:
                        self.backbutton.config(state="disabled", cursor="arrow")
                    self.urlbar.delete(0, "end")
                    self.urlbar.insert(0, url)
                    self.frame.load_url(url)
                    self.handle_view_source_button(url)

                def reload(self):
                    self.frame.load_url(self.back_history[-1], force=True)

                def change_title(self, title):
                    self.master.tab(self, text=self.cut_text(title, 40))

                def select_all(self):
                    if self.focus_get() not in (
                    self.urlbar, self.find_box, self.parsemode_box, self.zoom_box, self.fontscale_box,
                    self.broken_page_msg_box):
                        self.frame.select_all()

                def view_source(self):
                    if str(self.view_source_button.cget("state")) == "normal":
                        self.open_new_tab("view-source:" + self.urlbar.get())

            def __close():
                close()
                if len(frame.pages) > 1:
                    CreateDialog()

            def on_tab_change(event=None):
                if not frame.pages:
                    __close()

            main_frame = tk.Frame(window, highlightthickness=0, bd=0)

            frame = Notebook(main_frame)
            frame.bind("<<NotebookTabChanged>>", on_tab_change)

            window_bar.window_close['command'] = __close

            page = Page(frame)

            window.bind_all("<Up>", lambda e: frame.select().frame.html.yview_scroll(-5, "units"))
            window.bind_all("<Down>", lambda e: frame.select().frame.html.yview_scroll(5, "units"))
            window.bind_all("<Prior>", lambda e: frame.select().frame.html.yview_scroll(-1, "pages"))
            window.bind_all("<Next>", lambda e: frame.select().frame.html.yview_scroll(1, "pages"))
            window.bind_all("<Home>", lambda e: frame.select().frame.html.yview_moveto(0))
            window.bind_all("<End>", lambda e: frame.select().frame.html.yview_moveto(1))
            window.bind_all("<Control-w>", lambda e: frame.select().close_current_tab())
            window.bind_all("<Control-t>", lambda e: frame.select().open_new_tab())
            window.bind_all("<Control-f>", lambda e: frame.select().open_findbar(True))
            window.bind_all("<Control-b>", lambda e: frame.select().open_sidebar(True))
            window.bind_all("<Control-l>", lambda e: frame.select().urlbar_focus())
            window.bind_all("<Control-i>", lambda e: frame.select().hide_messsage_box(e))
            window.bind_all("<Control-r>", lambda e: frame.select().reloadbutton.invoke())
            window.bind_all("<Control-a>", lambda e: frame.select().select_all())
            window.bind_all("<Control-u>", lambda e: frame.select().view_source())
            window.bind_all("<Alt-Left>", lambda e: frame.select().back())
            window.bind_all("<Alt-Right>", lambda e: frame.select().forward())

            frame.pack(expand=True, fill="both")
            main_frame.pack(expand=True, fill="both")
            frame.add(page, text='')

            page.link_click(NEW_TAB, history=False)
        elif kw['id'] == 'sysinfo':

            if desktop.sysinfoopen:
                window_bar.destroy()
                window.destroy()
            else:
                desktop.sysinfoopen = 1

                window_width = 350
                window_height = 250
                window_bar['width'] = window_width
                window_bar.theme['width'] = window_width - 4
                window['width'] = window_width
                window['height'] = window_height
                window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['about'])
                window_bar.theme.coords(window_bar.window_label, window_width / 2, 20 / 2 + 2)

                window.x0['width'] = window_width
                window.x1['height'] = window_height+20
                window.y0['width'] = window_width + 2
                window.y1['height'] = window_height+20

                def sysinfoclose():
                    global desktop
                    close()
                    desktop.sysinfoopen = 0

                def tabswitch(tab):
                    if tab == 1:
                        tabsys.place(x=25, y=35)

                        tabs.aboutsys['font'] = ('TkDefaultFont', tk.EXCEPTION, 'bold')
                        tabs.aboutstr['font'] =  ('TkDefaultFont')
                        tabs.aboutnet['font'] =  ('TkDefaultFont')
                        tabs.aboutupd['font'] =  ('TkDefaultFont')

                        tabstr.place_forget()
                        tabnet.place_forget()
                        tabupd.place_forget()
                    elif tab == 2:
                        tabstr.place(x=25, y=35)
                        tabs.aboutstr['font'] = ('TkDefaultFont', tk.EXCEPTION, 'bold')
                        tabs.aboutsys['font'] = ('TkDefaultFont')
                        tabs.aboutnet['font'] = ('TkDefaultFont')
                        tabs.aboutupd['font'] = ('TkDefaultFont')
                        tabsys.place_forget()
                        tabnet.place_forget()
                        tabupd.place_forget()
                    elif tab == 3:
                        tabnet.place(x=25, y=35)
                        tabs.aboutnet['font'] = ('TkDefaultFont', tk.EXCEPTION, 'bold')
                        tabs.aboutstr['font'] = ('TkDefaultFont')
                        tabs.aboutsys['font'] = ('TkDefaultFont')
                        tabs.aboutupd['font'] = ('TkDefaultFont')
                        tabstr.place_forget()
                        tabsys.place_forget()
                        tabupd.place_forget()
                    elif tab == 4:
                        tabupd.place(x=25, y=35)
                        tabs.aboutupd['font'] = ('TkDefaultFont', tk.EXCEPTION, 'bold')
                        tabs.aboutstr['font'] = ('TkDefaultFont')
                        tabs.aboutnet['font'] = ('TkDefaultFont')
                        tabs.aboutsys['font'] = ('TkDefaultFont')
                        tabstr.place_forget()
                        tabnet.place_forget()
                        tabsys.place_forget()

                tabsys = tk.LabelFrame(window, width=300, height=200)
                tabsys.place(x=25, y=35)
                tabstr = tk.LabelFrame(window, width=300, height=200)
                tabnet = tk.LabelFrame(window, width=300, height=200)
                tabupd = tk.LabelFrame(window, width=300, height=200)

                window_bar.window_close['command'] = sysinfoclose

                tabsys.sysinfo = tk.Label(tabsys, text='  ' + reg.system['sysinfo']['class']['revsysname'] + ' ' + reg.system['sysinfo']['class']['revsysver'], font=('TkDefaultFont', 16, 'bold'), image=f_logo_sysinfo, compound='left')
                tabsys.sysinfo.place(relx=0.5, rely=0.2, anchor='center')
                tabsys.procinfo = tk.Label(tabsys, text= reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['cpu'] + ': ' + reg.system['sysinfo']['smbios']['cpu']['revcpuname'] + ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['at'] + ' ' +
                                                        str(reg.system['sysinfo']['smbios']['cpu']['revcpufreq']) + ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['ghz'] + ' ' + '\n' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['gpu'] + ': ' +
                                                        reg.system['sysinfo']['smbios']['gpu']['revgpuname'] + ' ' + str(reg.system['sysinfo']['smbios']['gpu']['revgpumem']) + ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['mbt'] + '\n' +
                                                         reg.system['locales'][
                                                             reg.system['sysinfo']['class']['revsyslang']][
                                                             'sysinfo']['mem'] + ': ' + reg.system['sysinfo']['smbios']['mem']['revmemname'] + ' ' +
                                                        str(reg.system['sysinfo']['smbios']['mem'][
                                                                'revmemval']) + ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['mbt'] + '\n' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['mbd'] + ': ' +
                                                        reg.system['sysinfo']['smbios']['mbd'][
                                                            'revmbdname'] + ' ' + str(reg.system['sysinfo']['smbios']['mbd']['revmbdsock'] + '\n') + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['aud'] + ': ' +
                                                        reg.system['sysinfo']['smbios']['aud']['revaudname'] + ' ' + reg.system['sysinfo']['smbios']['aud']['revaudmode'], justify='left')
                tabsys.procinfo.place(relx=0.5, y=125, anchor='center')
                tabsys.mbdinfo = tk.Label(tabsys, text=reg.system['sysinfo']['class']['revsysname'] + '© 2024-2025' + ' by ' + reg.system['sysinfo']['class']['revsyscreate'], font=('TkDefaultFont', 7, 'bold'))
                tabsys.mbdinfo.place(relx=0.5, y=185, anchor='center')

                tabstr.hddinfo = tk.Label(tabstr,
                                          text='  ' + reg.system['sysinfo']['smbios']['hdd']['revhddname'] + '\n  ' +
                                               reg.system['sysinfo']['smbios']['hdd']['revhddport'] + ' '
                                               + reg.system['sysinfo']['smbios']['hdd']['revhddtype'] + ' ' + str(
                                              reg.system['sysinfo']['smbios']['hdd']['revhddval']) +
                                               ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['mbt'], image=hdd_icon_sysinfo, compound='left', justify='left')
                tabstr.hddinfo.place(x=5, y=5)

                tabstr.hddpartinfo = tk.Label(tabstr, text='  ' + reg.system['sysinfo']['smbios']['hdd']['partitions']['part-1']['revhddname'] + '\n  ' + ' ' + str(reg.system['sysinfo']['smbios']['hdd']['partitions']['part-1']['revhddval']) +
                                                       ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['mbt'], image=hdd_icon_sysinfo, compound='left', justify='left')
                tabstr.hddpartinfo.place(x=25, y=45)

                tabstr.hddpartinfo1 = tk.Label(tabstr,
                                          text='  ' + reg.system['sysinfo']['smbios']['hdd']['partitions']['part-0']['revhddname'] + '\n  ' + ' ' + str(
                                              reg.system['sysinfo']['smbios']['hdd']['partitions']['part-0']['revhddval']) +
                                               ' ' + reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['mbt'], image=hdd_icon_sysinfo, compound='left', justify='left')
                tabstr.hddpartinfo1.place(x=25, y=85)

                tabstr.line = tk.Frame(tabstr, width=1, height=70, bg='black')
                tabstr.line.place(x=20, y=48)

                tabnet.netinfo = tk.Label(tabnet, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['lan'] + ': ' + reg.system['sysinfo']['smbios']['lan']['revlanname'] + ' ' + reg.system['sysinfo']['smbios']['lan']['revlanmode'])
                tabnet.netinfo.place(x=5, y=5)

                tabupd.status = tk.Label(tabupd, text='', font=('TkDefaultFont', 16, 'bold'))
                tabupd.status.place(relx=0.5, y=30, anchor='center')
                tabupd.status_low = tk.Label(tabupd, text='')
                tabupd.status_low.place(relx=0.5, y=65, anchor='center')


                if not reg.system['sysinfo']['class']['status']['revupdatestat']:
                    tabupd.status['text'] = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['noupdf']
                    tabupd.status_low['text'] = f"{reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['usinglast']} {reg.system['sysinfo']['class']['revsysname']} {reg.system['sysinfo']['class']['revsysver']}"
                else:
                    tabupd.status['text'] = f"{reg.system['sysinfo']['class']['status']['revupdatestat']} {reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['updfound']}"

                tabs = tk.LabelFrame(window, width=304, height=25)
                tabs.place(relx=0.5, rely=0.075, anchor='center')

                tabs.aboutsys = tk.Button(tabs, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['tab']['system'], command=lambda: tabswitch(1), font=('TkDefaultFont', tk.EXCEPTION, 'bold'))
                tabs.aboutsys.place(x=0, width=75, height=21)
                tabs.aboutstr = tk.Button(tabs, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['tab']['storage'], command=lambda: tabswitch(2), font=('TkDefaultFont'))
                tabs.aboutstr.place(x=75, width=75, height=21)
                tabs.aboutnet = tk.Button(tabs, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['tab']['network'], command=lambda: tabswitch(3), font=('TkDefaultFont'))
                tabs.aboutnet.place(x=150, width=75, height=21)
                tabs.aboutupd = tk.Button(tabs, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['tab']['update'], command=lambda: tabswitch(4), font=('TkDefaultFont'))
                tabs.aboutupd.place(x=225, width=75, height=21)

                window_bar.window_maximize.destroy()

        elif kw['id'] == 'word':

            window_width = 800
            window_height = 600
            window_bar['width'] = window_width
            window_bar.theme['width'] = window_width-4
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['word']['name'])
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            text_entry = tk.Text(window, font=('TkDefaultFont'))
            text_entry.place(x=0, y=69, width=window_width-4, height=window_height - 69 - 4)

            text_entry.tag_configure("red", background="red", foreground="black")
            text_entry.tag_configure("orange", background="orange", foreground="black")
            text_entry.tag_configure("yellow", background="yellow", foreground="black")
            text_entry.tag_configure("green", background="green", foreground="white")
            text_entry.tag_configure("cyan", background="cyan", foreground="black")
            text_entry.tag_configure("blue", background="blue", foreground="white")
            text_entry.tag_configure("purple", background="purple", foreground="white")
            text_entry.tag_configure("black", background="black", foreground="white")
            text_entry.tag_configure("white", background="white", foreground="black")
            text_entry.tag_configure("brown", background="#b97a57", foreground="black")
            text_entry.tag_configure("pink", background="#ffaec9", foreground="black")
            text_entry.tag_configure("lavender", background="#c8bfe7", foreground="black")
            text_entry.tag_configure("bluish", background="#7092be", foreground="black")
            text_entry.tag_configure("grass", background="#b5e61d", foreground="black")

            #fonts_8

            text_entry.tag_configure("times", font=('Times New Roman', 8))
            text_entry.tag_configure("courier", font=('Courier New', 8))
            text_entry.tag_configure("candara", font=('Candara', 8))
            text_entry.tag_configure("constantia", font=('Constantia', 8))
            text_entry.tag_configure("cascadia", font=('Cascadia Mono Light', 8))
            text_entry.tag_configure("standard", font=('TkDefaultFont', 8))

            #fonts_10

            text_entry.tag_configure("times10", font=('Times New Roman', 10))
            text_entry.tag_configure("courier10", font=('Courier New', 10))
            text_entry.tag_configure("candara10", font=('Candara', 10))
            text_entry.tag_configure("constantia10", font=('Constantia', 10))
            text_entry.tag_configure("cascadia10", font=('Cascadia Mono Light', 10))
            text_entry.tag_configure("standard10", font=('TkDefaultFont', 10))

            # fonts_12

            text_entry.tag_configure("times12", font=('Times New Roman', 12))
            text_entry.tag_configure("courier12", font=('Courier New', 12))
            text_entry.tag_configure("candara12", font=('Candara', 12))
            text_entry.tag_configure("constantia12", font=('Constantia', 12))
            text_entry.tag_configure("cascadia12", font=('Cascadia Mono Light', 12))
            text_entry.tag_configure("standard12", font=('TkDefaultFont', 12))

            # fonts_14

            text_entry.tag_configure("times14", font=('Times New Roman', 14))
            text_entry.tag_configure("courier14", font=('Courier New', 14))
            text_entry.tag_configure("candara14", font=('Candara', 14))
            text_entry.tag_configure("constantia14", font=('Constantia', 14))
            text_entry.tag_configure("cascadia14", font=('Cascadia Mono Light', 14))
            text_entry.tag_configure("standard14", font=('TkDefaultFont', 14))

            # fonts_16

            text_entry.tag_configure("times16", font=('Times New Roman', 16))
            text_entry.tag_configure("courier16", font=('Courier New', 16))
            text_entry.tag_configure("candara16", font=('Candara', 16))
            text_entry.tag_configure("constantia16", font=('Constantia', 16))
            text_entry.tag_configure("cascadia16", font=('Cascadia Mono Light', 16))
            text_entry.tag_configure("standard16", font=('TkDefaultFont', 16))

            # fonts_18

            text_entry.tag_configure("times18", font=('Times New Roman', 18))
            text_entry.tag_configure("courier18", font=('Courier New', 18))
            text_entry.tag_configure("candara18", font=('Candara', 18))
            text_entry.tag_configure("constantia18", font=('Constantia', 18))
            text_entry.tag_configure("cascadia18", font=('Cascadia Mono Light', 18))
            text_entry.tag_configure("standard18", font=('TkDefaultFont', 18))

            def color_text(tag):
                try:
                    text_entry.tag_add(tag, "sel.first", "sel.last")
                except:
                    pass

            def clear_color():
                text_entry.tag_remove("red", "1.0", 'end')
                text_entry.tag_remove("orange", "1.0", 'end')
                text_entry.tag_remove("yellow", "1.0", 'end')
                text_entry.tag_remove("green", "1.0", 'end')
                text_entry.tag_remove("cyan", "1.0", 'end')
                text_entry.tag_remove("blue", "1.0", 'end')
                text_entry.tag_remove("purple", "1.0", 'end')

            def clear_font():
                text_entry.tag_remove("times", "1.0", 'end')
                text_entry.tag_remove("courier", "1.0", 'end')
                text_entry.tag_remove("candara", "1.0", 'end')
                text_entry.tag_remove("cascadia", "1.0", 'end')
                text_entry.tag_remove("constantia", "1.0", 'end')
                text_entry.tag_remove("standard", "1.0", 'end')

            def font_text(tag):
                try:
                    text_entry.tag_add(tag, 'sel.first', 'sel.last')
                except:
                    pass

            def size_text(tag):
                try:
                    text_entry.tag_add(tag, 'sel.first', 'sel.last')
                except:
                    pass

            toolbar = tk.LabelFrame(window, width=window_width-4, height=69)
            toolbar.place(x=0)

            toolbar.color = tk.LabelFrame(toolbar, width=220, height=25 + 5 + 25)
            toolbar.color.place(x=window_width-220-4-4-5, y=5)
            toolbar.color.red = tk.Button(toolbar.color, bg='red', command=lambda: color_text('red'))
            toolbar.color.orange = tk.Button(toolbar.color, bg='orange', command=lambda: color_text('orange'))
            toolbar.color.yellow = tk.Button(toolbar.color, bg='yellow', command=lambda: color_text('yellow'))
            toolbar.color.green = tk.Button(toolbar.color, bg='green', command=lambda: color_text('green'))
            toolbar.color.cyan = tk.Button(toolbar.color, bg='cyan', command=lambda: color_text('cyan'))
            toolbar.color.blue = tk.Button(toolbar.color, bg='blue', command=lambda: color_text('blue'))
            toolbar.color.purple = tk.Button(toolbar.color, bg='purple', command=lambda: color_text('purple'))
            clear_btn = tk.Button(toolbar.color, text="Clear color", command=clear_color)
            toolbar.color.black = tk.Button(toolbar.color, bg='black', command=lambda: color_text('black'))
            toolbar.color.white = tk.Button(toolbar.color, bg='white', command=lambda: color_text('white'))
            toolbar.color.brown = tk.Button(toolbar.color, bg='#b97a57', command=lambda: color_text('brown'))
            toolbar.color.pink = tk.Button(toolbar.color, bg='#ffaec9', command=lambda: color_text('pink'))
            toolbar.color.lavender = tk.Button(toolbar.color, bg='#c8bfe7', command=lambda: color_text('lavender'))
            toolbar.color.bluish = tk.Button(toolbar.color, bg='#7092be', command=lambda: color_text('bluish'))
            toolbar.color.grass = tk.Button(toolbar.color, bg='#b5e61d', command=lambda: color_text('grass'))

            toolbar.color.black.place(x=3, y=3 + 15 + 3, width=15, height=15)
            toolbar.color.white.place(x=3 + 15 + 5, y=3 + 15 + 3, width=15, height=15)
            toolbar.color.brown.place(x=3 + 15 * 2 + 5 * 2, y=3 + 15 + 3, width=15, height=15)
            toolbar.color.pink.place(x=3 + 15 * 3 + 5 * 3, y=3 + 15 + 3, width=15, height=15)
            toolbar.color.lavender.place(x=3 + 15 * 4 + 5 * 4, y=3 + 15 + 3, width=15, height=15)
            toolbar.color.bluish.place(x=3 + 15 * 5 + 5 * 5, y=3 + 15 + 3, width=15, height=15)
            toolbar.color.grass.place(x=3 + 15 * 6 + 5 * 6, y=3 + 15 + 3, width=15, height=15)

            toolbar.color.red.place(x=3, y=3, width=15, height=15)
            toolbar.color.orange.place(x=3+15+5, y=3, width=15, height=15)
            toolbar.color.yellow.place(x=3+15*2+5*2, y=3, width=15, height=15)
            toolbar.color.green.place(x=3+15*3+5*3, y=3, width=15, height=15)
            toolbar.color.cyan.place(x=3+15*4+5*4, y=3, width=15, height=15)
            toolbar.color.blue.place(x=3+15*5+5*5, y=3, width=15, height=15)
            toolbar.color.purple.place(x=3+15*6+5*6, y=3, width=15, height=15)
            clear_btn.place(x=3+15*7+5*7, y=0, height=50)

            toolbar.font = tk.LabelFrame(toolbar, width=220, height=25)
            toolbar.font.place(x=5, y=5+25+5)

            toolbar.font.times = tk.Button(toolbar.font, text='Aa', command=lambda: font_text('times'), font=('Times New Roman', 8))
            toolbar.font.courier = tk.Button(toolbar.font, text='Aa', command=lambda: font_text('courier'), font=('Courier New', 8))
            toolbar.font.candara = tk.Button(toolbar.font, text='Aa', command=lambda: font_text('candara'), font=('Candara', 8))
            toolbar.font.constantia = tk.Button(toolbar.font, text='Aa', command=lambda: font_text('constantia'), font=('Constantia', 8))
            toolbar.font.cascadia = tk.Button(toolbar.font, text='Aa', command=lambda: font_text('cascadia'), font=('Cascadia Mono Light', 8))
            toolbar.font.standard = tk.Button(toolbar.font, text='Aa', command=lambda: font_text('standard'))
            clear_font_btn = tk.Button(toolbar.font, text="Clear font", command=clear_font)

            toolbar.font.times.place(x=3, y=3, width=20, height=15)
            toolbar.font.courier.place(x=3 + 20 + 5, y=3, width=20, height=15)
            toolbar.font.candara.place(x=3 + 20 * 2 + 5 * 2, y=3, width=20, height=15)
            toolbar.font.constantia.place(x=3 + 20 * 3 + 5 * 3, y=3, width=20, height=15)
            toolbar.font.cascadia.place(x=3 + 20 * 4 + 5 * 4, y=3, width=20, height=15)
            toolbar.font.standard.place(x=3 + 20 * 5 + 5 * 5, y=3, width=20, height=15)
            clear_font_btn.place(x=153, y=0, height=20)

            toolbar.font_size = tk.LabelFrame(toolbar, width=220, height=25)
            toolbar.font_size.place(x=5, y=5)

            toolbar.font_size.s8 = tk.Button(toolbar.font_size, text='8', command=lambda: color_text('times'))
            toolbar.font_size.s10 = tk.Button(toolbar.font_size, text='10', command=lambda: color_text('courier'))
            toolbar.font_size.s12 = tk.Button(toolbar.font_size, text='12', command=lambda: color_text('candara'))
            toolbar.font_size.s14 = tk.Button(toolbar.font_size, text='14', command=lambda: color_text('constantia'))
            toolbar.font_size.s16 = tk.Button(toolbar.font_size, text='16', command=lambda: color_text('cascadia'))
            toolbar.font_size.s18 = tk.Button(toolbar.font_size, text='18', command=lambda: color_text('standard'))
            toolbar.font_size.s20 = tk.Button(toolbar.font_size, text='20', command=lambda: color_text('times'))
            toolbar.font_size.s22 = tk.Button(toolbar.font_size, text='22', command=lambda: None)

            toolbar.font_size.s8.place(x=3, y=3, width=20, height=15)
            toolbar.font_size.s10.place(x=3 + 20 + 5, y=3, width=20, height=15)
            toolbar.font_size.s12.place(x=3 + 20 * 2 + 5 * 2, y=3, width=20, height=15)
            toolbar.font_size.s14.place(x=3 + 20 * 3 + 5 * 3, y=3, width=20, height=15)
            toolbar.font_size.s16.place(x=3 + 20 * 4 + 5 * 4, y=3, width=20, height=15)
            toolbar.font_size.s18.place(x=3 + 20 * 5 + 5 * 5, y=3, width=20, height=15)
            toolbar.font_size.s20.place(x=3 + 20 * 6 + 5 * 6, y=3, width=20, height=15)
            toolbar.font_size.s22.place(x=3 + 20 * 7 + 5 * 7, y=3, width=20, height=15)

        elif kw['id'] == 'mp':

            ___exit = 0

            def play():
                videoplayer.play()
                botbar.play['command'] = pause

            def pause():
                videoplayer.pause()
                botbar.play['command'] = play

            def update_dur():
                m, s = divmod(round(videoplayer.current_duration()), 60)
                m1, s1 = divmod(round(videoplayer.video_info()['duration']), 60)
                botbar.dur['text'] = str(m) + ':' + str(s)  + '/' + str(m1) + ':' + str(s1)

                if not ___exit:
                    nv.after(60, update_dur)

            def ___Close():
                global ___exit
                ___exit = 1
                close()

            def maximizem():
                maximize()

                window_bar.window_maximize['command'] = make_standm
                videoplayer.place(relx=0.5, rely=0.5, anchor='center', width=window_width - 4, height=window_height - 4 - 25)
                botbar.place(x=0, y=reg.system['screen']['height_px'] - 25 - 85 - 25 - 4)

            def make_standm():
                make_stand()

                window_bar.window_maximize['command'] = maximizem
                videoplayer.place(x=0, y=-13, width=window_width - 4, height=window_height - 4 - 25)
                botbar.place(x=0, y=window_height - 25 - 4)

            window_width = 1280
            window_height = 720
            window_bar['width'] = window_width
            window_bar.theme['width'] = window_width-4
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text='fusion Mediaviewer')
            window_bar.window_maximize['command'] = maximizem
            window_bar.window_close['command'] = ___Close
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            window['bg'] = 'black'

            botbar = tk.Frame(window, width=window_width-4, height=25)
            botbar.play = tk.Button(botbar, text='rule', command=play)
            botbar.place(x=0, y=window_height-25-4)
            botbar.play.place(x=2)
            botbar.dur = tk.Label(botbar, text='')
            botbar.dur.place(relx=0.5, y=15, anchor='center')

            videoplayer = TkinterVideo(window, scaled=True)
            videoplayer.place(x=0, y=0, width=window_width-4, height=window_height-4-25)
            videoplayer.load('C:/sample.mp4')

            update_dur()

        elif kw['id'] == 'calc':

            window_width = 124
            window_height = 229
            window_bar.theme['width'] = window_width-4
            window_bar['width'] = window_width
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['calc']['calc'])
            window_bar.window_maximize.destroy()
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)
            window_bar.window_minimize.place(x=window_width-12-4-3, y=3)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            def add_digit(digit):
                value = calc.get()
                if value[0] == '0' and len(value) == 1:
                    value = value[1:]
                calc.delete(0, tk.END)
                calc.insert(0, value + digit)

            def add_operation(operation):
                value = calc.get()
                if value[-1] in '-+/*':
                    value = value[:-1]
                elif '+' in value or '-' in value or '*' in value or '/' in value:
                    calculate()
                    value = calc.get()
                calc.delete(0, tk.END)
                calc.insert(0, value + operation)

            def calculate():
                value = calc.get()
                if value[-1] in '-+/*':
                    value = value + value[:-1]
                calc.delete(0, tk.END)
                try:
                    calc.insert(0, eval(value))
                except (NameError, SyntaxError):
                    calc.insert(0, 0)
                except ZeroDivisionError:
                    calc.insert(0, 0)

            def clear():
                calc.delete(0, tk.END)
                calc.insert(0, 0)

            calc = tk.Entry(window)
            calc.insert(0, '0')
            calc.place(x=0, width=window_width-4-25, height=25)

            b1 = tk.Button(window, text='1', command=lambda: add_digit('1'))
            b2 = tk.Button(window, text='2', command=lambda: add_digit('2'))
            b3 = tk.Button(window, text='3', command=lambda: add_digit('3'))
            b4 = tk.Button(window, text='4', command=lambda: add_digit('4'))
            b5 = tk.Button(window, text='5', command=lambda: add_digit('5'))
            b6 = tk.Button(window, text='6', command=lambda: add_digit('6'))
            b7 = tk.Button(window, text='7', command=lambda: add_digit('7'))
            b8 = tk.Button(window, text='8', command=lambda: add_digit('8'))
            b9 = tk.Button(window, text='9', command=lambda: add_digit('9'))
            b0 = tk.Button(window, text='0', command=lambda: add_digit('0'))
            bc = tk.Button(window, text='C', command=clear)
            bplus = tk.Button(window, text='+', command=lambda: add_operation('+'))
            bminus = tk.Button(window, text='-', command=lambda: add_operation('-'))
            bequals = tk.Button(window, text='=', command=calculate)
            bmult = tk.Button(window, text='*', command=lambda: add_operation('*'))
            bdivide = tk.Button(window, text='/', command=lambda: add_operation('/'))

            b1.place(x=0, y=25, width=40, height=40)
            b2.place(x=40, y=25, width=40, height=40)
            b3.place(x=80, y=25, width=40, height=40)
            b4.place(x=0, y=65, width=40, height=40)
            b5.place(x=40, y=65, width=40, height=40)
            b6.place(x=80, y=65, width=40, height=40)
            b7.place(x=0, y=105, width=40, height=40)
            b8.place(x=40, y=105, width=40, height=40)
            b9.place(x=80, y=105, width=40, height=40)
            bplus.place(x=0, y=145, width=40, height=40)
            b0.place(x=40, y=145, width=40, height=40)
            bminus.place(x=80, y=145, width=40, height=40)
            bmult.place(x=0, y=185, width=40, height=40)
            bequals.place(x=40, y=185, width=40, height=40)
            bdivide.place(x=80, y=185, width=40, height=40)
            bc.place(x=window_width-25-4, y=0, width=25, height=25)

        elif kw['id'] == 'paint':

            global brush_size, brush_color

            window_width = 600
            window_height = 400
            window_bar.theme['width'] = window_width-4
            window_bar['width'] = window_width
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text='fusion Draw')
            window_bar.window_maximize.destroy()
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            def paint(event):
                global brush_size
                global brush_color
                x1 = event.x - brush_size
                x2 = event.x + brush_size
                y1 = event.y - brush_size
                y2 = event.y + brush_size
                canva.create_oval(x1, y1, x2, y2, fill=brush_color, outline=brush_color)

            def fill():
                canva.create_rectangle(0, 0, 600, 400, fill=brush_color, outline=brush_color)

            def brush_size_change(newsize):
                global brush_size
                brush_size += newsize

            def brush_size_subtract(newsize):
                global brush_size
                brush_size -= newsize
                if brush_size < 1:
                    brush_size = 1

            def change_color(newcolor):
                global brush_color
                brush_color = newcolor

            brush_size = 3
            brush_color = 'black'
            canva = tk.Canvas(window, width=window_width - 4, height=window_height - 4, bg='white')
            canva.bind('<B1-Motion>', paint)
            canva.place(x=0, y=20, width=window_width-4, height=window_height-25)

            toolbar = tk.LabelFrame(window, width=window_width-4, height=30)
            toolbar.place(x=0)

            toolbar.red_btn = tk.Button(toolbar, bg='red', width=1, command=lambda: change_color("red"))
            toolbar.orange_btn = tk.Button(toolbar, bg='orange', width=1, command=lambda: change_color("orange"))
            toolbar.yellow_btn = tk.Button(toolbar, bg='yellow', width=1, command=lambda: change_color("yellow"))
            toolbar.green_btn = tk.Button(toolbar, bg='green', width=1, command=lambda: change_color("green"))
            toolbar.blue_btn = tk.Button(toolbar, bg='blue', width=1, command=lambda: change_color("blue"))
            toolbar.light_blue_btn = tk.Button(toolbar, bg='#00DBFF', width=1, command=lambda: change_color("#00DBFF"))
            toolbar.black_btn = tk.Button(toolbar, bg='black', width=1, command=lambda: change_color("black"))
            toolbar.white_btn = tk.Button(toolbar, bg='white', width=1, command=lambda: change_color("white"))
            toolbar.purple_btn = tk.Button(toolbar, bg='purple', width=1, command=lambda: change_color("purple"))
            toolbar.erase_btn = tk.Button(toolbar, text='Clear', command=lambda: canva.delete('all'))
            toolbar.add_btn = tk.Button(toolbar, text='+', width=1, command=lambda: brush_size_change(1))
            toolbar.sub_btn = tk.Button(toolbar, text='-', width=1, command=lambda: brush_size_subtract(1))
            toolbar.fill_btn = tk.Button(toolbar, text='Fill', command=fill)

            toolbar.red_btn.place(x=20, height=20)
            toolbar.orange_btn.place(x=40, height=20)
            toolbar.yellow_btn.place(x=60, height=20)
            toolbar.green_btn.place(x=80, height=20)
            toolbar.blue_btn.place(x=120, height=20)
            toolbar.light_blue_btn.place(x=100, height=20)
            toolbar.purple_btn.place(x=140, height=20)
            toolbar.black_btn.place(x=160, height=20)
            toolbar.white_btn.place(x=180, height=20)
            toolbar.erase_btn.place(x=490, height=20)
            toolbar.add_btn.place(x=560, height=20)
            toolbar.sub_btn.place(x=580, height=20)
            toolbar.fill_btn.place(x=540, height=20)

        elif kw['id'] == 'console':
            window_width = 600
            window_height = 400
            window_bar.theme['width'] = window_width-4
            window_bar['width'] = window_width
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['console']['name'])
            window_bar.window_maximize.destroy()
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            tex = tk.Label(window, text='fusion Console [Beta 1 | Build 1.021]\nDOS-like console\n', anchor='nw', justify='left', bg='black', fg='white')
            command_input = tk.Entry(window)
            tex.place(x=0, width=600-4, height=400-25-4)
            command_input.place(x=0, y=400-25-4, width=600-4, height=25)

            cmdl = {
                'cls': lambda: (tex.config(text='fusion Console [Beta 1 | Build 1.021]\nDOS-like console\n'))
            }

            def evaluate(command):
                 if command in cmdl:
                     cmdl[command]()
                 else:
                    command_input.delete(0, tk.END)
                    tex['text'] += ('\n' + str(os.popen(command).read()))

            command_input.bind('<Return>', lambda e: evaluate(command_input.get()))
        elif kw['id'] == 'irc-chat':
            def _self_close():
                menustr.windows.rem(window)
                nv.windows.remove(window)
                quit_all_servers()
                window_bar.destroy()
                window.destroy()
                desktop.window_x -= 50
                desktop.window_y -= 50

            window_width = 800
            window_height = 500
            window_bar.theme['width'] = window_width-4
            window_bar['width'] = window_width
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['irc-chat']['irc'])
            window_bar.window_maximize.destroy()
            window_bar.theme.coords(window_bar.window_label, window_width/2, 20/2+2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width+2
            window.y1['height'] = window_height+20

            window_bar.window_close['command'] = _self_close

            default_config_dir = platformdirs.user_config_path("mantaray", "Akuli")

            parser = argparse.ArgumentParser()

            config_dir_group = parser.add_mutually_exclusive_group()
            config_dir_group.add_argument(
                "--config-dir",
                type=Path,
                default=default_config_dir,
                help=(
                        "path to folder containing config.json and logs folder"
                        + f" (default: {default_config_dir})"
                ),
            )
            config_dir_group.add_argument(
                "--alice",
                action="store_true",
                help="equivalent to '--config-dir alice --dont-save-config', useful for developing mantaray",
            )
            config_dir_group.add_argument(
                "--bob",
                action="store_true",
                help="equivalent to '--config-dir bob --dont-save-config', useful for developing mantaray",
            )

            parser.add_argument(
                "--dont-save-config",
                action="store_true",
                help="do not write to config.json in the config dir",
            )
            parser.add_argument(
                "--verbose",
                action="store_true",
                help="print everything sent and received, useful for development and understanding IRC",
            )

            args = parser.parse_args()

            if args.alice:
                args.config_dir = Path("alice")
            if args.bob:
                args.config_dir = Path("bob")

            if args.config_dir != default_config_dir and not args.config_dir.is_dir():
                parser.error("the specified --config-dir must exist and be a directory")

            # tkinter must have one global root window, but server configging creates dialog
            # solution: hide root window temporarily

            settings = config.Settings(
                config_dir=args.config_dir,
                read_only=(args.alice or args.bob or args.dont_save_config),
            )
            if settings.read_only:
                print("Settings (read-only):", args.config_dir / "config.json")
            else:
                print("Settings:", args.config_dir / "config.json")
            print("Logs:", args.config_dir / "logs")

            try:
                settings.load()
            except FileNotFoundError:
                server_settings = config.ServerSettings()
                user_clicked_connect = config.show_connection_settings_dialog(
                    settings=server_settings, transient_to=None, connecting_to_new_server=True
                )
                if not user_clicked_connect:
                    return
                settings.add_server(server_settings)
                settings.save()


            def quit_all_servers():
                for server_view in irc_widget.get_server_views():
                    server_view.core.quit()

            irc_widget = gui.IrcWidget(
                window,
                settings,
                args.config_dir / "logs",
                verbose=args.verbose,
                after_quitting_all_servers=window.destroy,
            )
            irc_widget.pack(fill="both", expand=True)

            def add_binding(binding: str, callback: Callable[[], None]) -> None:
                def actual_callback(event: object) -> str:
                    callback()
                    return "break"

                if sys.platform == "darwin":
                    binding = binding.format(ControlOrCommand="Command")
                else:
                    binding = binding.format(ControlOrCommand="Control")

                # Must be bound on entry, otherwise Ctrl+PageUp runs PageUp code
                window.bind(binding, actual_callback)
                irc_widget.entry.bind(binding, actual_callback)
        elif kw['id'] == 'settings':
            window_width = 640
            window_height = 480
            window_bar.theme['width'] = window_width - 4
            window_bar['width'] = window_width
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['name'])
            window_bar.window_maximize.destroy()
            window_bar.theme.coords(window_bar.window_label, window_width / 2, 20 / 2 + 2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height+20
            window.y0['width'] = window_width + 2
            window.y1['height'] = window_height+20

            window.home = tk.Frame(window, width=window_width-4, height=window_height-4, relief="flat")
            window.home.place(x=0)

            def desktop_frame_open():
                window.desktop_frame.place(x=0)
                window.home.place_forget()

            def desktop_frame_close():
                window.home.place(x=0)
                window.desktop_frame.place_forget()

            def desktop_frame__wlp_hold(event):
                event.widget['bg'] = '#bdbdbd'

            def desktop_frame__wlp_leave(event):
                event.widget['bg'] = '#f0f0f0'

            def desktop_frame__thm_hold(event):
                event.widget['bg'] = '#bdbdbd'
                event.widget['borderwidth'] = 1

            def desktop_frame__thm_leave(event):
                event.widget['bg'] = '#f0f0f0'
                event.widget['borderwidth'] = 0

            def desktop_frame__sys_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = system_wallpaper

            def desktop_frame__pol_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = polar_wallpaper

            def desktop_frame__cld_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = clouds_wallpaper

            def desktop_frame__rn_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = rain_wallpaper

            def desktop_frame__lly_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = lily_wallpaper

            def desktop_frame__sea_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = sea_wallpaper

            def desktop_frame__sky_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = sky_wallpaper

            def desktop_frame__sk2_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = sky2_wallpaper

            def desktop_frame__sk3_wlp_press(event):
                event.widget['borderwidth'] = 1
                desktop.wallpaper['image'] = sky3_wallpaper

            def desktop_frame__sys_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['system']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = system_wallpaper
                focus()

            def desktop_frame__pol_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['polar']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = polar_wallpaper
                focus()

            def desktop_frame__cld_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['clouds']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = clouds_wallpaper
                focus()

            def desktop_frame__rn_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['rain']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = rain_wallpaper
                focus()

            def desktop_frame__lly_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['lily']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = lily_wallpaper
                focus()

            def desktop_frame__sea_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['sea']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = sea_wallpaper
                focus()

            def desktop_frame__sky_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['sky']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = sky_wallpaper
                focus()

            def desktop_frame__sk2_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['sky2']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = sky2_wallpaper
                focus()

            def desktop_frame__sk3_thm_press(event):
                global current_color_scheme
                current_color_scheme = reg.system['theme']['theme']['sky3']
                event.widget['borderwidth'] = 2
                for i in nv.windows:
                    i.bar.theme._draw_gradient()
                desktop.wallpaper['image'] = sky3_wallpaper
                focus()

            def desktop_frame__wlp_release(event):
                event.widget['borderwidth'] = 0

            window.desktop_frame = tk.Frame(window, width=window_width-4, height=window_height-4, relief="flat")

            window.desktop_frame.wlp_label = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['name'])
            window.desktop_frame.wlp_label.place(x=window_width/2/2, y=10, anchor='center')

            ttk.Separator(window.desktop_frame, orient='vertical').place(x=window_width/2, height=window_height-4)

            window.desktop_frame.thm_label = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['theme']['name'])
            window.desktop_frame.thm_label.place(x=window_width/2+window_width/2/2, y=10, anchor='center')

            window.desktop_frame.sys_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['system'], image=system_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.sys_wlp.place(x=3, y=20)
            window.desktop_frame.pol_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['polar'], image=polar_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.pol_wlp.place(x=108, y=20)
            window.desktop_frame.cld_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['clouds'], image=clouds_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.cld_wlp.place(x=213, y=20)
            window.desktop_frame.sea_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['sea'], image=sea_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.sea_wlp.place(x=3, y=125)
            window.desktop_frame.rn_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['rain'], image=rain_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.rn_wlp.place(x=108, y=125)
            window.desktop_frame.lly_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['lily'], image=lily_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.lly_wlp.place(x=213, y=125)
            window.desktop_frame.sky_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['sky'], image=sky_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.sky_wlp.place(x=3, y=230)
            window.desktop_frame.sk2_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['sky2'], image=sky2_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.sk2_wlp.place(x=108, y=230)
            window.desktop_frame.sk3_wlp = tk.Label(window.desktop_frame, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['desktop_frame']['wallpaper']['sky3'], image=sky3_wallpaper_preview, compound='top', relief='solid', borderwidth=0)
            window.desktop_frame.sk3_wlp.place(x=213, y=230)

            window.desktop_frame.sys_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.sys_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.pol_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.pol_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.cld_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.cld_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.sys_wlp.bind('<ButtonPress-1>', desktop_frame__sys_wlp_press)
            window.desktop_frame.sys_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.pol_wlp.bind('<ButtonPress-1>', desktop_frame__pol_wlp_press)
            window.desktop_frame.pol_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.cld_wlp.bind('<ButtonPress-1>', desktop_frame__cld_wlp_press)
            window.desktop_frame.cld_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.lly_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.lly_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.sea_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.sea_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.rn_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.rn_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.lly_wlp.bind('<ButtonPress-1>', desktop_frame__lly_wlp_press)
            window.desktop_frame.lly_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sea_wlp.bind('<ButtonPress-1>', desktop_frame__sea_wlp_press)
            window.desktop_frame.sea_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.rn_wlp.bind('<ButtonPress-1>', desktop_frame__rn_wlp_press)
            window.desktop_frame.rn_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sky_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.sky_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.sk2_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.sk2_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.sk3_wlp.bind('<Enter>', desktop_frame__wlp_hold)
            window.desktop_frame.sk3_wlp.bind('<Leave>', desktop_frame__wlp_leave)
            window.desktop_frame.sky_wlp.bind('<ButtonPress-1>', desktop_frame__sky_wlp_press)
            window.desktop_frame.sky_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sk2_wlp.bind('<ButtonPress-1>', desktop_frame__sk2_wlp_press)
            window.desktop_frame.sk2_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sk3_wlp.bind('<ButtonPress-1>', desktop_frame__sk3_wlp_press)
            window.desktop_frame.sk3_wlp.bind('<ButtonRelease-1>', desktop_frame__wlp_release)

            window.desktop_frame.system_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['system'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.system_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=20)
            window.desktop_frame.polar_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['polar'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.polar_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=50)
            window.desktop_frame.cloud_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['clouds'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.cloud_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=80)
            window.desktop_frame.sea_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['sea'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.sea_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=110)
            window.desktop_frame.rain_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['rain'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.rain_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=140)
            window.desktop_frame.lily_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['lily'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.lily_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=170)
            window.desktop_frame.sky_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['sky'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.sky_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=200)
            window.desktop_frame.sky2_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['sky2'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.sky2_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=230)
            window.desktop_frame.sky3_theme = BarGradientFrame(window.desktop_frame, reg.system['theme']['theme']['sky3'], width=window_width/2-4-10, height=20, relief='solid', borderwidth=0)
            window.desktop_frame.sky3_theme.place(x=window_width-(window_width/2-4-10)-4-6, y=260)

            window.desktop_frame.system_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.system_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.polar_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.polar_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.cloud_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.cloud_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.sea_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.sea_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.rain_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.rain_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.lily_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.lily_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.sky_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.sky_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.sky2_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.sky2_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.sky3_theme.bind('<Enter>', desktop_frame__thm_hold)
            window.desktop_frame.sky3_theme.bind('<Leave>', desktop_frame__thm_leave)
            window.desktop_frame.system_theme.bind('<ButtonPress-1>', desktop_frame__sys_thm_press)
            window.desktop_frame.system_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.polar_theme.bind('<ButtonPress-1>', desktop_frame__pol_thm_press)
            window.desktop_frame.polar_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.cloud_theme.bind('<ButtonPress-1>', desktop_frame__cld_thm_press)
            window.desktop_frame.cloud_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sea_theme.bind('<ButtonPress-1>', desktop_frame__sea_thm_press)
            window.desktop_frame.sea_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.rain_theme.bind('<ButtonPress-1>', desktop_frame__rn_thm_press)
            window.desktop_frame.rain_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.lily_theme.bind('<ButtonPress-1>', desktop_frame__lly_thm_press)
            window.desktop_frame.lily_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sky_theme.bind('<ButtonPress-1>', desktop_frame__sky_thm_press)
            window.desktop_frame.sky_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sky2_theme.bind('<ButtonPress-1>', desktop_frame__sk2_thm_press)
            window.desktop_frame.sky2_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)
            window.desktop_frame.sky3_theme.bind('<ButtonPress-1>', desktop_frame__sk3_thm_press)
            window.desktop_frame.sky3_theme.bind('<ButtonRelease-1>', desktop_frame__wlp_release)

            window.desktop_btn = tk.Button(window.home, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['dsktp'], compound='top', image=desktop_icon_settings, font=('TkDefaultFont', 7), command=desktop_frame_open)
            window.desktop_btn.place(x=5, y=5, width=75, height=75)
            window.theme_btn = tk.Button(window.home, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['theme'], compound='top', image=None, font=('TkDefaultFont', 7))
            window.theme_btn.place(x=85, y=5, width=75, height=75)
            #desktop_btn = tk.Button(window, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['dsktp'], compound='top', image=None, font=('TkDefaultFont', 7))
            #desktop_btn.place(x=5, y=5, width=75, height=75)
            #desktop_btn = tk.Button(window, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['dsktp'], compound='top', image=None, font=('TkDefaultFont', 7))
            #desktop_btn.place(x=5, y=5, width=75, height=75)
            #desktop_btn = tk.Button(window, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['dsktp'], compound='top', image=None, font=('TkDefaultFont', 7))
            #desktop_btn.place(x=5, y=5, width=75, height=75)
            #desktop_btn = tk.Button(window, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['dsktp'], compound='top', image=None, font=('TkDefaultFont', 7))
            #desktop_btn.place(x=5, y=5, width=75, height=75)
        elif kw['id'] == 'dialog':
            if "func" in kw:
                window_width = 200
                window_height = 200
                window_bar.theme['width'] = window_width - 4
                window_bar['width'] = window_width
                window['width'] = window_width
                window['height'] = window_height
                window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['system']['dialog'])
                window_bar.window_maximize.destroy()
                window_bar.theme.coords(window_bar.window_label, window_width / 2, 20 / 2 + 2)

                window.x0['width'] = window_width
                window.x1['height'] = window_height
                window.y0['width'] = window_width + 2
                window.y1['height'] = window_height
                yes_btn = tk.Button()
            else:
                print('"func" must be in kwargs while building dialog')
        elif kw['id'] == 'vkapp':
            window_width = 860
            window_height = 640
            window_bar.theme['width'] = window_width - 4
            window_bar['width'] = window_width
            window['width'] = window_width
            window['height'] = window_height
            window_bar.theme.itemconfig(window_bar.window_label, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['vk']['name'])
            window_bar.theme.coords(window_bar.window_label, window_width / 2, 20 / 2 + 2)

            window.x0['width'] = window_width
            window.x1['height'] = window_height
            window.y0['width'] = window_width + 2
            window.y1['height'] = window_height

            __vk_app_main_frame__(window)

    nv.windows.append(window)
    window.minimized = window_minimized
    window.minimize = minimize

    focus()

    menustr.windows.add(window)

    desktop.window_x += 50
    desktop.window_y += 50

freyo_browser_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['freyo'])
calc_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['calc'])
word_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['word'])
paint_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['paint'])
hdd_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['hdd'])
mp_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['mp'])
recycle0_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['recycle-0'])
recycle1_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['recycle-1'])
settings_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['settings'])
terminal_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['terminal'])
vkapp_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['vkapp'])
chat_icon_dock = tk.PhotoImage(file=reg.system['theme']['programs']['dock']['chat'])

clock_icon_system = tk.PhotoImage(file=reg.system['theme']['programs']['system']['clock'])

desktop_icon_settings = tk.PhotoImage(file=reg.system['theme']['programs']['settings']['desktop'])

f_logo_sysinfo = tk.PhotoImage(file=reg.system['theme']['programs']['sysinfo']['f_logo'])
hdd_icon_sysinfo = tk.PhotoImage(file=reg.system['theme']['programs']['sysinfo']['hdd'])

f_logo_menu = tk.PhotoImage(file=reg.system['theme']['programs']['menu']['f_logo'])

system_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['system'])
polar_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['polar'])
clouds_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['clouds'])
lily_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['lily'])
sea_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['sea'])
rain_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['rain'])
sky_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['sky'])
sky2_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['sky2'])
sky3_wallpaper = tk.PhotoImage(file=reg.system['theme']['wallpaper']['sky3'])

system_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['system']).resize((100, 78)))
polar_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['polar']).resize((100, 78)))
clouds_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['clouds']).resize((100, 78)))
lily_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['lily']).resize((100, 78)))
sea_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['sea']).resize((100, 78)))
rain_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['rain']).resize((100, 78)))
sky_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['sky']).resize((100, 78)))
sky2_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['sky2']).resize((100, 78)))
sky3_wallpaper_preview = ImageTk.PhotoImage(Image.open(reg.system['theme']['wallpaper']['sky3']).resize((100, 78)))

nv.title('опенвк')

desktop = tk.Frame(nv)
desktop.sysinfoopen = 0
desktop.minimized_windows = 0
desktop.window_x, desktop.window_y = 35, 35

nv.windows = []
nv.__cond_mmn_ = 0

def _menustr_add(child, **kw):
    globals()[child.bar.theme.itemcget(child.bar.window_label, 'text') + '_0_wndw'] = tk.Button(menustr.windows, text=child.bar.theme.itemcget(child.bar.window_label, 'text'), command=child.minimize)
    globals()[child.bar.theme.itemcget(child.bar.window_label, 'text') + '_0_wndw'].place(x=5 + 130 * (len(nv.windows) - 1), y=0, width=130, height=25-4)

def _menustr_rem(child, **kw):
    globals()[child.bar.theme.itemcget(child.bar.window_label, 'text') + '_0_wndw'].destroy()

def __showmainmenu():
    global nv
    if nv.__cond_mmn_ == 0:
        menustr.mainmenu.place(x=1, y=0)
        nv.__cond_mmn_ = 1
    elif nv.__cond_mmn_ == 1:
        menustr.mainmenu.place_forget()
        nv.__cond_mmn_ = 0


desktop.wallpaper = tk.Label(desktop, bg='gray', image=system_wallpaper)
desktop.wallpaper.place(x=0, width=reg.system['screen']['width_px'], height=reg.system['screen']['height_px']-25)
desktop.place(x=0, y=25, width=reg.system['screen']['width_px'], height=reg.system['screen']['height_px']-25)
menustr = tk.Frame(nv, relief='raised', borderwidth=2, bg='white', width=reg.system['screen']['width_px'], height=25)
menustr.place(x=0)

with open('conf', 'r') as __file__:
    __file_raw__ = __file__.read()
    __file_list__ = __file_raw__.split('\n')
    for i in __file_list__:
        a = i.split(':')
        if a[0] == 'thm' and a[1] in reg.system['theme']['theme']:
            current_color_scheme = reg.system['theme']['theme'][a[1]]
            current_theme_text = a[1]
            for b in nv.windows:
                b.bar.theme._draw_gradient()
            desktop.wallpaper['image'] = globals()[a[1]+'_wallpaper']
        elif a[0] == 'wlp' and a[1] in globals():
            desktop.wallpaper['image'] = globals()[a[1]]
            current_wallpaper_text = a[1]


nv.sleepw = tk.Label(nv, width=reg.system['screen']['width_px'], height=reg.system['screen']['height_px'], bg='#000000')

menustr.mainmenu = tk.Frame(desktop, width=82, height=200, relief='raised', borderwidth=2)

def ___shut__down___():
    #os.system('del conf')
    with open('conf', 'w'):
        pass
        #towrite = f"thm:{}\nwlp:"

menustr.mainmenu.btn1 = tk.Button(menustr.mainmenu, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['sysinfo']['about'], command=lambda: (CreateWindow(id='sysinfo'), __showmainmenu()))
menustr.mainmenu.btn1.place(x=0, y=0, width=78, height=20)
menustr.mainmenu.btn2 = tk.Button(menustr.mainmenu, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['system']['sleep'], command=lambda: (nv.sleepw.place(x=0), nv.bind('<Control-l>', lambda event: (nv.sleepw.place_forget(), nv.bind('<Control-l>', lambda event: print('')), __showmainmenu(), nv.sleepw.lift()))))
menustr.mainmenu.btn2.place(x=0, y=20, width=78, height=20)
menustr.mainmenu.btn3 = tk.Button(menustr.mainmenu, text=reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['system']['sh-dn'], command=___shut__down___)
menustr.mainmenu.btn3.place(x=0, y=40, width=78, height=20)

menustr.mainmenubtn = tk.Button(menustr, text=reg.system['sysinfo']['class']['revsysname'], command=__showmainmenu, bg='#f0f0f0', image=f_logo_menu, compound='left')
menustr.mainmenubtn.place(x=1, y=0, height=25-4)

ttk.Separator(menustr, orient='vertical').place(x=80, height=25-4, y=0)
menustr.windows = tk.Frame(menustr)
menustr.windows.add = _menustr_add
menustr.windows.rem = _menustr_rem
menustr.windows.place(x=82, y=0, width=reg.system['screen']['width_px'] - 50 - 30 - 91, height=25-4)
ttk.Separator(menustr, orient='vertical').place(x=83 + reg.system['screen']['width_px'] - 50 - 30 - 92, y=0, height=25-4)
desktop.dock = tk.Frame(desktop, relief='raised', borderwidth=2, width=555+68, height=128, bg='#cfd1cd')
desktop.dock.place(relx=0.5, y=reg.system['screen']['height_px']-35, anchor='center')

def changeLang():
    keyboard.send('alt+shift')

def squats():
    u = ctypes.windll.LoadLibrary("user32.dll")
    pf = getattr(u, "GetKeyboardLayout")
    if hex(pf(0)) == '0x4190419':
        lang_lbl['text'] = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['system']['ru']
    if hex(pf(0)) == '0x4090409':
        lang_lbl['text'] = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['system']['en']

    time_lbl.config(text=f"{datetime.now():%H:%M}")

    hour = int(time.strftime("%I"))
    mint = int(time.strftime("%M"))
    sec = int(time.strftime("%S"))

    sec_x = clock_widget.sec_hand_len * math.sin(math.radians(sec * 6)) + clock_widget.center_x
    sec_y = -1 * clock_widget.sec_hand_len * math.cos(math.radians(sec * 6)) + clock_widget.center_y
    clock_widget.coords(clock_widget.sec_hand, clock_widget.center_x, clock_widget.center_y, sec_x, sec_y)

    min_x = clock_widget.min_hand_len * math.sin(math.radians(mint * 6)) + clock_widget.center_x
    min_y = -1 * clock_widget.min_hand_len * math.cos(math.radians(mint * 6)) + clock_widget.center_y
    clock_widget.coords(clock_widget.min_hand, clock_widget.center_x, clock_widget.center_y, min_x, min_y)

    hour_x = clock_widget.hour_hand_len * math.sin(math.radians(hour * 30)) + clock_widget.center_x
    hour_y = -1 * clock_widget.hour_hand_len * math.cos(math.radians(hour * 30)) + clock_widget.center_y
    clock_widget.coords(clock_widget.hour_hand, clock_widget.center_x, clock_widget.center_y, hour_x, hour_y)

    sex = -1

    if not nv.windows == []:
        for child in nv.windows:
            sex += 1
            globals()[child.bar.theme.itemcget(child.bar.window_label, 'text') + '_0_wndw'].place(x=5 + 130 * sex - 1, y=0, width=130, height=25 - 4)

    nv.after(100, squats)

time_lbl = tk.Label(menustr, text='', bg='white')
time_lbl.place(x=reg.system['screen']['width_px'] - 50, height=25-4)

lang_lbl = tk.Button(menustr, text='', relief='flat', bg='white', command=changeLang)
lang_lbl.place(x=reg.system['screen']['width_px'] - 50 - 36, height=25-4, width=37)

def _dock__on_hold_(e=None):
    e.widget['text'] = e.widget.lble

def _dock__on_leave_(e=None):
    e.widget['text'] = ''

desktop.test_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=freyo_browser_icon_dock, command=lambda: CreateWindow(id='browser'), compound='top', font=('TkDefaultFont', 7))
desktop.test_icon.place(x=5, y=5)
desktop.test1_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=calc_icon_dock, command=lambda: CreateWindow(id='calc'), compound='top', font=('TkDefaultFont', 7))
desktop.test1_icon.place(x=68+5, y=5)
desktop.test2_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=word_icon_dock, command=lambda: CreateWindow(id='word'), compound='top', font=('TkDefaultFont', 7))
desktop.test2_icon.place(x=68*2+5, y=5)
desktop.test3_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=chat_icon_dock, command=lambda: CreateWindow(id='irc-chat'), compound='top', font=('TkDefaultFont', 7))
desktop.test3_icon.place(x=68*3+5, y=5)
desktop.test4_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=terminal_icon_dock, command=lambda: CreateWindow(id='console'), compound='top', font=('TkDefaultFont', 7))
desktop.test4_icon.place(x=68*4+5, y=5)
desktop.test5_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=vkapp_icon_dock, command=lambda: CreateWindow(id='vkapp'), compound='top', font=('TkDefaultFont', 7))
desktop.test5_icon.place(x=68*5+5, y=5)
desktop.test6_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=paint_icon_dock, command=lambda: CreateWindow(id='paint'), compound='top', font=('TkDefaultFont', 7))
desktop.test6_icon.place(x=68*6+5, y=5)
desktop.test7_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=mp_icon_dock, command=lambda: CreateWindow(id='mp'), compound='top', font=('TkDefaultFont', 7))
desktop.test7_icon.place(x=68*7+5, y=5)
desktop.test8_icon = tk.Button(desktop.dock, relief='raised', borderwidth=2, width=68-10, height=64-10, bg='white', fg='black', image=settings_icon_dock, command=lambda: CreateWindow(id='settings'), compound='top', font=('TkDefaultFont', 7))
desktop.test8_icon.place(x=68*8+5, y=5)

desktop.test_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['browser']['name']
desktop.test1_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['calc']['calc']
desktop.test2_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['word']['name']
desktop.test3_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['irc-chat']['irc']
desktop.test4_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['console']['name']
desktop.test5_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['vk']['name']
desktop.test6_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['draw']['name']
desktop.test7_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['mediaplayer']['name']
desktop.test8_icon.lble = reg.system['locales'][reg.system['sysinfo']['class']['revsyslang']]['settings']['name']

desktop.test_icon.bind('<Enter>', _dock__on_hold_)
desktop.test_icon.bind('<Leave>', _dock__on_leave_)
desktop.test1_icon.bind('<Enter>', _dock__on_hold_)
desktop.test1_icon.bind('<Leave>', _dock__on_leave_)
desktop.test2_icon.bind('<Enter>', _dock__on_hold_)
desktop.test2_icon.bind('<Leave>', _dock__on_leave_)
desktop.test3_icon.bind('<Enter>', _dock__on_hold_)
desktop.test3_icon.bind('<Leave>', _dock__on_leave_)
desktop.test4_icon.bind('<Enter>', _dock__on_hold_)
desktop.test4_icon.bind('<Leave>', _dock__on_leave_)
desktop.test5_icon.bind('<Enter>', _dock__on_hold_)
desktop.test5_icon.bind('<Leave>', _dock__on_leave_)
desktop.test6_icon.bind('<Enter>', _dock__on_hold_)
desktop.test6_icon.bind('<Leave>', _dock__on_leave_)
desktop.test7_icon.bind('<Enter>', _dock__on_hold_)
desktop.test7_icon.bind('<Leave>', _dock__on_leave_)
desktop.test8_icon.bind('<Enter>', _dock__on_hold_)
desktop.test8_icon.bind('<Leave>', _dock__on_leave_)

clock_widget = tk.Canvas(desktop, width=150, height=150, relief='raised', borderwidth=2)
clock_widget.ctrl_pressed = 0
clock_widget.place(x=reg.system['screen']['width_px']-150-15, y=5)

clock_widget.sec_hand_len = 50
clock_widget.min_hand_len = 40
clock_widget.hour_hand_len = 35
clock_widget.center_x = 79
clock_widget.center_y = 79

clock_widget.create_image(clock_widget.center_x, clock_widget.center_y, image=clock_icon_system)

clock_widget.sec_hand = clock_widget.create_line(20, 20, 20 + clock_widget.sec_hand_len, 20 + clock_widget.sec_hand_len, width=1.5, fill="#fd0d0d")
clock_widget.min_hand = clock_widget.create_line(20, 20, 20 + clock_widget.min_hand_len, 20 + clock_widget.min_hand_len, width=2, fill="#0d0d0d")
clock_widget.hour_hand = clock_widget.create_line(20, 20, 20 + clock_widget.hour_hand_len, 20 + clock_widget.hour_hand_len, width=4, fill="#0d0d0d")

puzzle_widget = tk.Canvas(desktop, width=150, height=150, relief='raised', borderwidth=2)
puzzle_widget.place(x=reg.system['screen']['width_px']-150-15, y=170)
puzzle_widget.pack_propagate(0)

puzzle_widget.SIZE = 3
puzzle_widget.frm = []
puzzle_widget.btn = []
puzzle_widget.playArea = list(range(1, puzzle_widget.SIZE * puzzle_widget.SIZE)) + [0]
puzzle_widget.game = False
puzzle_widget.timeGame = time.time()
puzzle_widget.sort = 0

class __puzzle__(tk.Button):
    def __init__(self, number=0, parent=None, **config):
        self.number = number
        tk.Button.__init__(self, parent, **config)
        self.pack(side='left', expand='yes', fill='both')
        self.config(font=('TkDefaultFont', 10), command=self.play)

    def play(self):
        global puzzle_widget
        m = puzzle_widget.playArea.index(0)
        if (abs(m - self.number) + abs(self.number // puzzle_widget.SIZE - m // puzzle_widget.SIZE)) == 1 or abs(m - self.number) == puzzle_widget.SIZE:
            puzzle_widget.playArea[m], puzzle_widget.playArea[self.number] = puzzle_widget.playArea[self.number], puzzle_widget.playArea[m]
            puzzle_widget.btn[m].config(text=puzzle_widget.playArea[m])
            self.config(text=" ")
            if puzzle_widget.game:
                for i in range(0, puzzle_widget.SIZE * puzzle_widget.SIZE):
                    if puzzle_widget.playArea[i] != i + 1:
                        break
                    if i + 2 == puzzle_widget.SIZE * puzzle_widget.SIZE:
                        puzzle_widget.game = False
                        puzzle_widget.sort = 0
                        nv.after(1000, __puzzle_new_game__)

for i in range(0, puzzle_widget.SIZE):
    puzzle_widget.frm.append(tk.Frame(puzzle_widget))
    puzzle_widget.frm[i].pack(expand='yes', fill='both')
    for j in range(0, puzzle_widget.SIZE):
        puzzle_widget.btn.append(__puzzle__((i * puzzle_widget.SIZE + j), puzzle_widget.frm[i]))

def __puzzle_new_game__():
    global puzzle_widget
    puzzle_widget.sort += 1
    if puzzle_widget.sort < puzzle_widget.SIZE ** 5:
        m = puzzle_widget.playArea.index(0)
        n = choice(range(0, puzzle_widget.SIZE * puzzle_widget.SIZE))
        if (abs(m - n) + abs(n // puzzle_widget.SIZE - m // puzzle_widget.SIZE)) == 1 or abs(m - n) == puzzle_widget.SIZE:
            puzzle_widget.btn[n].play()
            nv.after(1, __puzzle_new_game__)
        else:
            __puzzle_new_game__()
    else:
        puzzle_widget.game = True
        puzzle_widget.timeGame = time.time()

__puzzle_new_game__()

squats()
nv.mainloop()